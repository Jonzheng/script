insert into t_weapon values (null,'防卫队合体式盾斧1',1,468,0,'','blast:150','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:30,warning:60,yellow:20,success:90,dark:200|danger:30,warning:60,yellow:20,success:140,dark:150','','',250,'防卫队衍生','防衛隊合體式盾斧Ⅰ','','防卫队合体式盾斧2',0);

insert into t_weapon values (null,'防卫队合体式盾斧2',3,612,0,'','blast:180','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:30,warning:60,yellow:20,success:140,dark:150|danger:30,warning:60,yellow:20,success:150,blue:40,dark:100','惊愕的！毒妖鸟！调查！','',250,'防卫队衍生','防衛隊合體式盾斧Ⅱ','防卫队合体式盾斧1','防卫队合体式盾斧3',0);

insert into t_weapon values (null,'防卫队合体式盾斧3',5,684,0,'','blast:210','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:50,warning:50,yellow:50,success:80,blue:70,dark:100|danger:50,warning:50,yellow:50,success:80,blue:120,dark:50','樱火龙','',250,'防卫队衍生','防衛隊合體式盾斧Ⅲ','防卫队合体式盾斧2','防卫队合体式盾斧4',0);

insert into t_weapon values (null,'防卫队合体式盾斧4',6,756,0,'','blast:240','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:30,warning:50,yellow:50,success:80,blue:90,dark:100|danger:30,warning:50,yellow:50,success:80,blue:140,dark:50','灭尽龙','',250,'防卫队衍生','防衛隊合體式盾斧Ⅳ','防卫队合体式盾斧3','防卫队合体式盾斧5',3);

insert into t_weapon values (null,'防卫队合体式盾斧5',7,792,0,'','blast:270','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:90,warning:30,yellow:30,success:110,blue:40,white:50,dark:50|danger:90,warning:30,yellow:30,success:110,blue:40,white:100,dark:0','灭尽龙','',250,'防卫队衍生','防衛隊合體式盾斧Ⅴ','防卫队合体式盾斧4','',2);


insert into t_weapon values (null,'调查团试作盾斧1',1,288,0,'','','','','将铁快速加工后制成的盾斧。因量产而粗制滥造的部分相当明显，但即使是外行人也能使出像模像样的一击。','danger:90,warning:50,yellow:60,dark:200|danger:90,warning:50,yellow:80,success:30,dark:150','','',250,'矿石素材衍生','調查團試作盾斧Ⅰ','','调查团试作盾斧2',0);

insert into t_weapon values (null,'调查团试作盾斧2',1,324,0,'','','','','将铁快速加工后制成的盾斧。因量产而粗制滥造的部分相当明显，但即使是外行人也能使出像模像样的一击。','danger:70,warning:70,yellow:30,success:30,dark:200|danger:70,warning:70,yellow:30,success:80,dark:150','泥鱼龙','',250,'矿石素材衍生','調查團試作盾斧Ⅱ','调查团试作盾斧1','调查团试作盾斧3|泥流盾斧1',0);

insert into t_weapon values (null,'调查团试作盾斧3',2,360,0,'','','','','将铁快速加工后制成的盾斧。因量产而粗制滥造的部分相当明显，但即使是外行人也能使出像模像样的一击。','danger:50,warning:70,yellow:30,success:50,dark:200|danger:50,warning:70,yellow:30,success:100,dark:150','辉龙石','',250,'矿石素材衍生','調查團試作盾斧Ⅲ','调查团试作盾斧2','精锐调查团盾斧1',0);

insert into t_weapon values (null,'精锐调查团盾斧1',3,396,0,'','','','','以精炼的钢铁制成的盾斧。为了应付难度高的狩猎而进行改造，使得破坏力与强韧度更加提升。','danger:70,warning:50,yellow:80,success:50,dark:150|danger:70,warning:50,yellow:80,success:100,dark:100','火龙','',250,'矿石素材衍生','精銳調查團盾斧Ⅰ','调查团试作盾斧3','精锐调查团盾斧2|火龙盾斧1',0);

insert into t_weapon values (null,'精锐调查团盾斧2',4,468,0,'','','','','以精炼的钢铁制成的盾斧。为了应付难度高的狩猎而进行改造，使得破坏力与强韧度更加提升。','danger:50,warning:50,yellow:80,success:70,dark:150|danger:50,warning:50,yellow:80,success:120,dark:100','灵鹤石','',250,'矿石素材衍生','精銳調查團盾斧Ⅱ','精锐调查团盾斧1','精锐调查团盾斧3',0);

insert into t_weapon values (null,'精锐调查团盾斧3',5,504,0,'','thunder:(120)','','66','以精炼的钢铁制成的盾斧。为了应付难度高的狩猎而进行改造，使得破坏力与强韧度更加提升。','danger:100,warning:50,yellow:50,success:80,blue:20,dark:100|danger:100,warning:50,yellow:50,success:80,blue:70,dark:50','白鸠石','',250,'矿石素材衍生','精銳調查團盾斧Ⅲ','精锐调查团盾斧2','铬铁守护者1',0);

insert into t_weapon values (null,'铬铁守护者1',6,576,0,'','thunder:(150)','','66','灌注了大量稀有钢铁的盾斧。这把赌上匠师名誉而成的杰作，可在挥手之间斩破坚甲。','danger:80,warning:50,yellow:50,success:80,blue:40,dark:100|danger:80,warning:50,yellow:50,success:80,blue:90,dark:50','灭尽龙','',250,'矿石素材衍生','鉻鐵守護者Ⅰ','精锐调查团盾斧3','铬铁守护者2|灭尽龙的挥击',3);

insert into t_weapon values (null,'铬铁守护者2',6,648,0,'','thunder:(270)','','66,66','灌注了大量稀有钢铁的盾斧。这把赌上匠师名誉而成的杰作，可在挥手之间斩破坚甲。','danger:60,warning:60,yellow:20,success:150,blue:60,dark:50|danger:60,warning:60,yellow:20,success:150,blue:90,white:20,dark:0','粗活就交给猛牛龙','',250,'矿石素材衍生','鉻鐵守護者Ⅱ','铬铁守护者1','铬钢堡垒1',3);

insert into t_weapon values (null,'铬钢堡垒1',9,792,0,'','thunder:(300)','','66,66','工房匠人倾全力打造，全身均以稀有钢铁加工而成的盾斧。具有无法防御的强大破坏力。','danger:90,warning:80,yellow:30,success:30,blue:80,white:40,dark:50|danger:90,warning:80,yellow:30,success:30,blue:80,white:90,dark:0','雷狼龙','',250,'矿石素材衍生','鉻鋼堡壘Ⅰ','铬铁守护者2','铬钢堡垒2|王盾斧雷纹',0);

insert into t_weapon values (null,'铬钢堡垒2',10,864,0,'','thunder:(330)','','66,66','工房匠人倾全力打造，全身均以稀有钢铁加工而成的盾斧。具有无法防御的强大破坏力。','danger:80,warning:80,yellow:30,success:30,blue:80,white:50,dark:50|danger:80,warning:80,yellow:30,success:30,blue:80,white:100,dark:0','古龙的净血','',250,'矿石素材衍生','鉻鋼堡壘Ⅱ','铬钢堡垒1','铬钢堡垒3',0);

insert into t_weapon values (null,'铬钢堡垒3',11,972,0,'','thunder:(360)','','66,66','工房匠人倾全力打造，全身均以稀有钢铁加工而成的盾斧。具有无法防御的强大破坏力。','danger:120,warning:30,yellow:30,success:60,blue:50,white:60,dark:50|danger:120,warning:30,yellow:30,success:60,blue:50,white:80,purple:30,dark:0','古龙的净血','',250,'矿石素材衍生','鉻鋼堡壘Ⅲ','铬钢堡垒2','',0);

insert into t_weapon values (null,'王盾斧雷纹',10,864,0,'','thunder:330','','67','雷狼龙的盾斧。一口气解放雷电之力时，猎物将瞬间消失，化为焦炭。','danger:90,warning:80,yellow:30,success:30,blue:80,white:40,dark:50|danger:90,warning:80,yellow:30,success:30,blue:80,white:90,dark:0','雷狼龙','',250,'雷狼龙衍生','王盾斧雷紋','铬钢堡垒1','王盾斧雷纹·改',0);

insert into t_weapon values (null,'王盾斧雷纹·改',11,900,0,'','thunder:360','','67','雷狼龙的盾斧。一口气解放雷电之力时，猎物将瞬间消失，化为焦炭。','danger:120,warning:30,yellow:90,success:30,blue:30,white:50,dark:50|danger:120,warning:30,yellow:90,success:30,blue:30,white:80,purple:20,dark:0','灵脉的刚龙骨','',250,'雷狼龙衍生','王盾斧雷紋‧改','王盾斧雷纹','王牙盾斧【风雷】',0);

insert into t_weapon values (null,'王牙盾斧【风雷】',12,936,0,'','thunder:390','','67','雷狼龙的盾斧。一口气解放雷电之力时，猎物将瞬间消失，化为焦炭。','danger:110,warning:30,yellow:90,success:30,blue:30,white:60,dark:50|danger:110,warning:30,yellow:90,success:30,blue:30,white:90,purple:20,dark:0','灵脉的刚龙骨','',250,'雷狼龙衍生','王牙盾斧【風雷】','王盾斧雷纹·改','',0);
insert into t_weapon values (null,'灭尽龙的挥击',7,720,0,'','dragon:120','龙封力[大]','66','灭尽龙的盾斧。几经数次脱胎换骨的异质素材，将为敌方带来永无止境的痛苦。','danger:110,warning:120,yellow:40,success:50,blue:80,dark:0|danger:110,warning:120,yellow:40,success:50,blue:80,dark:0','收束之地','',250,'灭尽龙衍生','滅盡龍的揮擊','铬铁守护者1','坏灭之一束',2);

insert into t_weapon values (null,'坏灭之一束',8,756,0,'','dragon:150','龙封力[大]','66','灭尽龙的盾斧。这些针代表罪人所犯的罪行数量。每一刺，便可洗净一条罪行。','danger:100,warning:120,yellow:40,success:50,blue:90,dark:0|danger:100,warning:120,yellow:40,success:50,blue:90,dark:0','歼世灭尽龙','',250,'灭尽龙衍生','壞滅一束','灭尽龙的挥击','坏灭一束【裂】',1);

insert into t_weapon values (null,'坏灭一束【裂】',12,1044,0,'','dragon:210','龙封力[大]','66','歼世灭尽龙的盾斧。「罪孽深重的人啊，接受惩罚吧」让哭嚎的千支针刺向所有罪孽。','danger:80,warning:30,yellow:30,success:110,blue:40,white:110,dark:0|danger:80,warning:30,yellow:30,success:110,blue:40,white:110,dark:0','歼世灭尽龙','',250,'灭尽龙衍生','壞滅一束【裂】','坏灭之一束','',0);

insert into t_weapon values (null,'火龙盾斧1',4,432,0,'+10%','fire:150','','','火龙的盾斧。由于附加了火龙的素材，因此能够使出带有高热的攻击。','danger:60,warning:50,yellow:80,success:60,dark:150|danger:60,warning:50,yellow:80,success:110,dark:100','爆炎袋','',250,'火龙衍生','火龍盾斧Ⅰ','精锐调查团盾斧1','火龙盾斧2',0);

insert into t_weapon values (null,'火龙盾斧2',5,576,0,'+10%','fire:180','','66','火龙的盾斧。由于附加了火龙的素材，因此能够使出带有高热的攻击。','danger:100,warning:50,yellow:80,success:70,dark:100|danger:100,warning:50,yellow:80,success:100,blue:20,dark:50','火龙的上鳞','',250,'火龙衍生','火龍盾斧Ⅱ','火龙盾斧1','炎斧蛇王',0);

insert into t_weapon values (null,'炎斧蛇王',6,612,0,'+20%','fire:210','','66','火龙的盾斧。封入火龙的愤怒的刀刃，据说不但能够劈开大地，还能够撕裂天空。','danger:90,warning:50,yellow:50,success:80,blue:30,dark:100|danger:90,warning:50,yellow:50,success:80,blue:80,dark:50','苍火龙','',250,'火龙衍生','炎斧蛇王','火龙盾斧2','焰斧鹤王',3);

insert into t_weapon values (null,'焰斧鹤王',7,684,0,'+20%','fire:240','','66','火龙的盾斧。封入火龙的愤怒的刀刃，据说不但能够劈开大地，还能够撕裂天空。','danger:70,warning:50,yellow:60,success:120,blue:50,dark:50|danger:70,warning:50,yellow:60,success:120,blue:60,white:40,dark:0','火龙的重壳','',250,'火龙衍生','焰斧鶴王','炎斧蛇王','焰斧鹤王·改',2);

insert into t_weapon values (null,'焰斧鹤王·改',10,792,0,'+20%','fire:270','','66','火龙的盾斧。封入火龙的愤怒的刀刃，据说不但能够劈开大地，还能够撕裂天空。','danger:100,warning:100,yellow:40,success:50,blue:60,dark:50|danger:100,warning:100,yellow:40,success:50,blue:60,white:50,dark:0','苍火龙的重壳','',250,'火龙衍生','焰斧鶴王‧改','焰斧鹤王','魂魄斩苍炎斧',0);

insert into t_weapon values (null,'魂魄斩苍炎斧',10,864,0,'+20%','fire:300','','66','苍火龙的盾斧。寄宿于武器上的苍火龙魂，引诱猎人前往充满荣耀的狩猎。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','银火龙','',250,'火龙衍生','魂魄斬蒼炎斧','焰斧鹤王·改','业火斧狱雷',0);

insert into t_weapon values (null,'业火斧狱雷',12,972,0,'+20%','fire:330','','67','苍火龙的盾斧。可进行更为强力的燃烧攻击。','danger:110,warning:30,yellow:90,success:30,blue:30,white:60,dark:50|danger:110,warning:30,yellow:90,success:30,blue:30,white:90,purple:20,dark:0','银火龙','',250,'火龙衍生','業火斧獄雷','魂魄斩苍炎斧','',0);

insert into t_weapon values (null,'泥流盾斧1',2,396,0,'','water:120','','','泥鱼龙的盾斧。附加了像泥土般的硬质素材，并以充满野性的外观与超群的强度自豪。','danger:80,warning:70,yellow:30,success:20,dark:200|danger:80,warning:70,yellow:30,success:70,dark:150','雌火龙','',250,'泥鱼龙衍生','泥流盾斧Ⅰ','调查团试作盾斧2','泥流盾斧2|焰火盾斧',0);

insert into t_weapon values (null,'泥流盾斧2',3,432,0,'','water:150','','','泥鱼龙的盾斧。附加了像泥土般的硬质素材，并以充满野性的外观与超群的强度自豪。','danger:90,warning:50,yellow:80,success:30,dark:150|danger:90,warning:50,yellow:80,success:80,dark:100','风漂龙','',250,'泥鱼龙衍生','泥流盾斧Ⅱ','泥流盾斧1','泥流盾斧3|冰结盾斧1',0);

insert into t_weapon values (null,'泥流盾斧3',4,504,0,'','water:180','','','泥鱼龙的盾斧。附加了像泥土般的硬质素材，并以充满野性的外观与超群的强度自豪。','danger:80,warning:50,yellow:80,success:40,dark:150|danger:80,warning:50,yellow:80,success:90,dark:100','泥鱼龙的上鳞','',250,'泥鱼龙衍生','泥流盾斧Ⅲ','泥流盾斧2','深沉泥鱼1',0);

insert into t_weapon values (null,'深沉泥鱼1',5,576,0,'','water:210','','66','泥鱼龙的盾斧。其猛烈的一击乃是无与伦比的，据说能够将猎物如灰尘般撕裂。','danger:110,warning:50,yellow:80,success:60,dark:100|danger:110,warning:50,yellow:80,success:100,blue:10,dark:50','坚龙骨','',250,'泥鱼龙衍生','深沉泥岩Ⅰ','泥流盾斧3','深沉泥鱼2',0);

insert into t_weapon values (null,'深沉泥鱼2',6,648,0,'','water:240','','66','泥鱼龙的盾斧。其猛烈的一击乃是无与伦比的，据说能够将猎物如灰尘般撕裂。','danger:110,warning:50,yellow:50,success:80,blue:10,dark:100|danger:110,warning:50,yellow:50,success:80,blue:60,dark:50','古龙骨','',250,'泥鱼龙衍生','深沉泥岩Ⅱ','深沉泥鱼1','深沉泥鱼3',3);

insert into t_weapon values (null,'深沉泥鱼3',6,684,0,'','water:270','','66','泥鱼龙的盾斧。其猛烈的一击乃是无与伦比的，据说能够将猎物如灰尘般撕裂。','danger:100,warning:60,yellow:60,success:100,blue:30,dark:50|danger:100,warning:60,yellow:60,success:100,blue:50,white:30,dark:0','冰鱼龙','',250,'泥鱼龙衍生','深沉泥岩Ⅲ','深沉泥鱼2','深沉风土1|深沉霜雪1',3);

insert into t_weapon values (null,'深沉风土1',9,792,0,'','water:300','','68,66','泥鱼龙的盾斧。由纯洁的泥土所打造，具有肆虐万物的猛烈破坏力。','danger:90,warning:100,yellow:40,success:50,blue:70,dark:50|danger:90,warning:100,yellow:40,success:50,blue:70,white:50,dark:0','迅龙','',250,'泥鱼龙衍生','深沉風土Ⅰ','深沉泥鱼3','深沉风土2|隐密守护者1',0);

insert into t_weapon values (null,'深沉风土2',10,936,0,'','water:360','','68,66','泥鱼龙的盾斧。由纯洁的泥土所打造，具有肆虐万物的猛烈破坏力。','danger:90,warning:100,yellow:40,success:50,blue:70,dark:50|danger:90,warning:100,yellow:40,success:50,blue:70,white:50,dark:0','重龙骨','',250,'泥鱼龙衍生','深沉風土Ⅱ','深沉风土1','',0);
insert into t_weapon values (null,'隐密守护者1',10,792,0,'+15%','poison:(360)','','','迅龙的盾斧。被研磨至极限的素材，足以让观者沉迷于其锋锐。','danger:100,warning:80,yellow:30,success:30,blue:80,white:30,dark:50|danger:100,warning:80,yellow:30,success:30,blue:80,white:80,dark:0','雷颚龙','',250,'迅龙衍生','隱密守護者Ⅰ','深沉风土1','隐密守护者2',0);

insert into t_weapon values (null,'隐密守护者2',10,828,0,'+20%','poison:(420)','','66','迅龙的盾斧。被研磨至极限的素材，足以让观者沉迷于其锋锐。','danger:130,warning:20,yellow:20,success:70,blue:40,white:30,purple:40,dark:50|danger:130,warning:20,yellow:20,success:70,blue:40,white:30,purple:90,dark:0','雷颚龙','',250,'迅龙衍生','隱密守護者Ⅱ','隐密守护者1','',0);
insert into t_weapon values (null,'深沉霜雪1',9,756,0,'','ice:360','','67,66','冰鱼龙的盾斧。用极寒之地锻铸而成的素材打造，具有惊人的高强度。','danger:70,warning:80,yellow:30,success:30,blue:80,white:60,dark:50|danger:70,warning:80,yellow:30,success:30,blue:80,white:110,dark:0','霜翼风漂龙','',250,'冰鱼龙衍生','深沉霜雪Ⅰ','深沉泥鱼3','深沉霜雪2',0);

insert into t_weapon values (null,'深沉霜雪2',10,900,0,'','ice:480','','67,66','冰鱼龙的盾斧。用极寒之地锻铸而成的素材打造，具有惊人的高强度。','danger:70,warning:80,yellow:30,success:30,blue:80,white:60,dark:50|danger:70,warning:80,yellow:30,success:30,blue:80,white:110,dark:0','霜翼风漂龙','',250,'冰鱼龙衍生','深沉霜雪Ⅱ','深沉霜雪1','',0);
insert into t_weapon values (null,'冰结盾斧1',4,504,0,'','ice:150','','','被赋予了冰属性的铁制盾斧。使用了来自于加工屋的新技术，因其特殊表面涂层而带有属性。','danger:70,warning:50,yellow:80,success:50,dark:150|danger:70,warning:50,yellow:80,success:100,dark:100','灵鹤石','',250,'冰属性衍生','冰結盾斧Ⅰ','泥流盾斧2','冰结盾斧2',0);

insert into t_weapon values (null,'冰结盾斧2',5,540,0,'','ice:180','','66,66','被赋予了冰属性的铁制盾斧。使用了来自于加工屋的新技术，因其特殊表面涂层而带有属性。','danger:100,warning:50,yellow:80,success:70,dark:100|danger:100,warning:50,yellow:80,success:100,blue:20,dark:50','白鸠石','',250,'冰属性衍生','冰結盾斧Ⅱ','冰结盾斧1','寒霜巨人1',0);

insert into t_weapon values (null,'寒霜巨人1',6,576,0,'','ice:210','','67,67','被赋予了冰属性的铁制盾斧。为了提升属性与威力，而进行了细致且大胆的改造。','danger:100,warning:50,yellow:50,success:80,blue:20,dark:100|danger:100,warning:50,yellow:50,success:80,blue:70,dark:50','古龙之血','',250,'冰属性衍生','寒霜巨人Ⅰ','冰结盾斧2','寒霜巨人2',3);

insert into t_weapon values (null,'寒霜巨人2',6,612,0,'','ice:240','','67,67','被赋予了冰属性的铁制盾斧。为了提升属性与威力，而进行了细致且大胆的改造。','danger:90,warning:60,yellow:80,success:80,blue:40,dark:50|danger:90,warning:60,yellow:80,success:80,blue:70,white:20,dark:0','雪光金属','',250,'冰属性衍生','寒霜巨人Ⅱ','寒霜巨人1','寒霜巨人3',3);

insert into t_weapon values (null,'寒霜巨人3',9,720,0,'','ice:270','','67,67','被赋予了冰属性的铁制盾斧。为了提升属性与威力，而进行了细致且大胆的改造。','danger:70,warning:60,yellow:60,success:100,blue:60,dark:50|danger:70,warning:60,yellow:60,success:100,blue:80,white:30,dark:0','冰牙龙','',250,'冰属性衍生','寒霜巨人Ⅲ','寒霜巨人2','纯白骑士',0);

insert into t_weapon values (null,'纯白骑士',10,756,0,'+20%','ice:300','','','冰牙龙的盾斧。极寒刀刃会使猎物瞬间冻结，感觉不到被一刀两断的痛楚。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','冰牙龙票','',250,'冰属性衍生','純白騎士','寒霜巨人3','纯白骑士·改|愤怒之狼',0);

insert into t_weapon values (null,'纯白骑士·改',10,864,0,'+25%','ice:330','','','冰牙龙的盾斧。极寒刀刃会使猎物瞬间冻结，感觉不到被一刀两断的痛楚。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','冰呪龙','',250,'冰属性衍生','純白騎士‧改','纯白骑士','悍怒之狼',0);

insert into t_weapon values (null,'悍怒之狼',11,900,0,'+30%','ice:360','','','冰牙龙的盾斧。极寒刀刃会使猎物瞬间冻结，感觉不到被一刀两断的痛楚。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','冰呪龙','',250,'冰属性衍生','悍怒之狼','纯白骑士·改','',0);


