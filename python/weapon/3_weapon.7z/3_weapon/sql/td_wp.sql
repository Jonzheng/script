insert into t_weapon values (null,'防卫队连刃式太刀1',1,429,0,'','blast:180','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:30,warning:60,yellow:20,success:90,dark:200|danger:30,warning:60,yellow:20,success:140,dark:150','','',243,'防卫队衍生','防衛隊連刃式太刀Ⅰ','','防卫队连刃式太刀2',0);

insert into t_weapon values (null,'防卫队连刃式太刀2',3,561,0,'','blast:210','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:30,warning:60,yellow:20,success:140,dark:150|danger:30,warning:60,yellow:20,success:150,blue:40,dark:100','惊愕的！毒妖鸟！调查！','',243,'防卫队衍生','防衛隊連刃式太刀Ⅱ','防卫队连刃式太刀1','防卫队连刃式太刀3',0);

insert into t_weapon values (null,'防卫队连刃式太刀3',5,627,0,'','blast:240','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:50,warning:50,yellow:50,success:80,blue:70,dark:100|danger:50,warning:50,yellow:50,success:80,blue:120,dark:50','樱火龙','',243,'防卫队衍生','防衛隊連刃式太刀Ⅲ','防卫队连刃式太刀2','防卫队连刃式太刀4',0);

insert into t_weapon values (null,'防卫队连刃式太刀4',6,693,0,'','blast:270','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:30,warning:50,yellow:50,success:80,blue:90,dark:100|danger:30,warning:50,yellow:50,success:80,blue:140,dark:50','灭尽龙','',243,'防卫队衍生','防衛隊連刃式太刀Ⅳ','防卫队连刃式太刀3','防卫队连刃式太刀5',3);

insert into t_weapon values (null,'防卫队连刃式太刀5',7,726,0,'','blast:300','','','为了防卫队制作的轻弩。集结了工房技术的精髓，得以实现前所未有的卓越性能。','danger:90,warning:30,yellow:30,success:110,blue:40,white:50,dark:50|danger:90,warning:30,yellow:30,success:110,blue:40,white:100,dark:0','灭尽龙','',243,'防卫队衍生','防衛隊連刃式太刀Ⅴ','防卫队连刃式太刀4','',2);
insert into t_weapon values (null,'铁刀1',1,264,0,'','','','','将铁快速加工后制成的太刀。因量产而粗制滥造的部分相当明显，但即使是外行人也能使出像模像样的一闪。','danger:100,warning:50,yellow:50,dark:200|danger:100,warning:50,yellow:80,success:20,dark:150','','',243,'矿石素材衍生','鐵刀Ⅰ','','铁刀2',0);

insert into t_weapon values (null,'铁刀2',1,297,0,'','','','','将铁快速加工后制成的太刀。因量产而粗制滥造的部分相当明显，但即使是外行人也能使出像模像样的一闪。','danger:80,warning:70,yellow:30,success:20,dark:200|danger:80,warning:70,yellow:30,success:70,dark:150','搔鸟','',243,'矿石素材衍生','鐵刀Ⅱ','铁刀1','铁刀3|星空太刀1',0);

insert into t_weapon values (null,'铁刀3',2,330,0,'','','','','将铁快速加工后制成的太刀。因量产而粗制滥造的部分相当明显，但即使是外行人也能使出像模像样的一闪。','danger:60,warning:70,yellow:30,success:40,dark:200|danger:60,warning:70,yellow:30,success:90,dark:150','眩鸟','',243,'矿石素材衍生','鐵刀Ⅲ','铁刀2','铁刀【禊】1|眩刀【摇】1',0);

insert into t_weapon values (null,'铁刀【禊】1',3,363,0,'','','','','以精钢铁制成的太刀。针对高难度的狩猎而进行了改造，使得破坏力与强韧度进一步提升。','danger:80,warning:50,yellow:80,success:40,dark:150|danger:80,warning:50,yellow:80,success:90,dark:100','上龙骨','',243,'矿石素材衍生','鐵刀【禊】Ⅰ','铁刀3','铁刀【禊】2',0);

insert into t_weapon values (null,'铁刀【禊】2',4,429,0,'','','','','以精钢铁制成的太刀。针对高难度的狩猎而进行了改造，使得破坏力与强韧度进一步提升。','danger:70,warning:50,yellow:80,success:50,dark:150|danger:70,warning:50,yellow:80,success:100,dark:100','灵鹤石','',243,'矿石素材衍生','鐵刀【禊】Ⅱ','铁刀【禊】1','铁刀【禊】3',0);

insert into t_weapon values (null,'铁刀【禊】3',5,462,0,'','water:(120)','','67','以精钢铁制成的太刀。针对高难度的狩猎而进行了改造，使得破坏力与强韧度进一步提升。','danger:90,warning:50,yellow:50,success:80,blue:30,dark:100|danger:90,warning:50,yellow:50,success:80,blue:80,dark:50','白鸠石','',243,'矿石素材衍生','鐵刀【禊】Ⅲ','铁刀【禊】2','铁刀【神乐】1',0);

insert into t_weapon values (null,'铁刀【神乐】1',6,528,0,'','water:(150)','','67','灌注了大量稀有钢铁的太刀。这把赌上匠师名誉而成的杰作，可在挥手之间斩破坚甲。','danger:70,warning:50,yellow:50,success:80,blue:50,dark:100|danger:70,warning:50,yellow:50,success:80,blue:100,dark:50','灭尽龙','',243,'矿石素材衍生','鐵刀【神樂】Ⅰ','铁刀【禊】3','铁刀【神乐】2|灭尽龙太刀',3);

insert into t_weapon values (null,'铁刀【神乐】2',6,594,0,'','water:(180)','','67,67','灌注了大量稀有钢铁的太刀。这把赌上匠师名誉而成的杰作，可在挥手之间斩破坚甲。','danger:50,warning:60,yellow:20,success:150,blue:70,dark:50|danger:50,warning:60,yellow:20,success:150,blue:90,white:30,dark:0','粗活就交给猛牛龙','',243,'矿石素材衍生','鐵刀【神樂】Ⅱ','铁刀【神乐】1','铁刀【神威】1',3);

insert into t_weapon values (null,'铁刀【神威】1',9,726,0,'','water:(210)','','67,67','全身均以稀有钢铁加工而成的太刀。具有无法防御的强大锋锐度。','danger:90,warning:80,yellow:30,success:30,blue:80,white:40,dark:50|danger:90,warning:80,yellow:30,success:30,blue:80,white:90,dark:0','雷狼龙','',243,'矿石素材衍生','鐵刀【神威】Ⅰ','铁刀【神乐】2','铁刀【神威】2|王刀雷切',0);

insert into t_weapon values (null,'铁刀【神威】2',10,792,0,'','water:(240)','','67,67','全身均以稀有钢铁加工而成的太刀。具有无法防御的强大锋锐度。','danger:80,warning:80,yellow:30,success:30,blue:80,white:50,dark:50|danger:80,warning:80,yellow:30,success:30,blue:80,white:100,dark:0','黑狼鸟','',243,'矿石素材衍生','鐵刀【神威】Ⅱ','铁刀【神威】1','铁刀【神威】3|大刀【乌】',0);

insert into t_weapon values (null,'铁刀【神威】3',11,858,0,'','water:(270)','','67,67','全身均以稀有钢铁加工而成的太刀。具有无法防御的强大锋锐度。','danger:120,warning:30,yellow:30,success:60,blue:50,white:60,dark:50|danger:120,warning:30,yellow:30,success:60,blue:50,white:80,purple:30,dark:0','古龙的净血','',243,'矿石素材衍生','鐵刀【神威】Ⅲ','铁刀【神威】2','',0);

insert into t_weapon values (null,'大刀【乌】',10,858,0,'+20%','poison:210','','67','黑狼鸟的太刀。强者总是孤独，剑士的爱刀。','danger:150,warning:30,yellow:90,success:30,blue:30,white:20,dark:50|danger:150,warning:30,yellow:90,success:30,blue:30,white:50,purple:20,dark:0','伤痕紫甲壳','',243,'黑狼鸟衍生','大刀【烏】','铁刀【神威】2','大刀【狼】',0);

insert into t_weapon values (null,'大刀【狼】',11,891,0,'+25%','poison:240','','67','黑狼鸟的太刀。强者总是孤独，剑士的爱刀。','danger:140,warning:30,yellow:90,success:30,blue:30,white:30,dark:50|danger:140,warning:30,yellow:90,success:30,blue:30,white:60,purple:20,dark:0','伤痕紫甲壳','',243,'黑狼鸟衍生','大刀【狼】','大刀【乌】','',0);

insert into t_weapon values (null,'王刀雷切',10,792,0,'','thunder:240','','68','雷狼龙的太刀。若世上有神明的话，此刚强太刀可神挡杀神、佛挡杀佛。','danger:100,warning:80,yellow:30,success:30,blue:80,white:30,dark:50|danger:100,warning:80,yellow:30,success:30,blue:80,white:80,dark:0','雷狼龙','',243,'雷狼龙衍生','王刀雷切','铁刀【神威】1','王刀雷切·改',0);

insert into t_weapon values (null,'王刀雷切·改',11,825,0,'','thunder:300','','68','雷狼龙的太刀。若世上有神明的话，此刚强太刀可神挡杀神、佛挡杀佛。','danger:130,warning:30,yellow:90,success:30,blue:30,white:40,dark:50|danger:130,warning:30,yellow:90,success:30,blue:30,white:70,purple:20,dark:0','灵脉的刚龙骨','',243,'雷狼龙衍生','王刀雷切‧改','王刀雷切','王牙刀【伏雷】',0);

insert into t_weapon values (null,'王牙刀【伏雷】',12,858,0,'','thunder:450','','68','雷狼龙的太刀。若世上有神明的话，此刚强太刀可神挡杀神、佛挡杀佛。','danger:120,warning:30,yellow:90,success:30,blue:30,white:50,dark:50|danger:120,warning:30,yellow:90,success:30,blue:30,white:80,purple:20,dark:0','灵脉的刚龙骨','',243,'雷狼龙衍生','王牙刀【伏雷】','王刀雷切·改','',0);

insert into t_weapon values (null,'灭尽龙太刀',7,627,0,'','dragon:90','龙封力[大]','67','灭尽龙的太刀。几经数次脱胎换骨的异质素材，将为敌人带来永无止境的痛苦。','danger:120,warning:120,yellow:40,success:50,blue:70,dark:0|danger:120,warning:120,yellow:40,success:50,blue:70,dark:0','收束之地','',243,'灭尽龙衍生','滅盡龍太刀','铁刀【神乐】1','灭尽一刀',2);

insert into t_weapon values (null,'灭尽一刀',8,693,0,'','dragon:120','龙封力[大]','67','灭尽龙的太刀。因罪而被囚禁的罪人灵魂，终将通过这把刀而获得解脱。','danger:110,warning:120,yellow:40,success:50,blue:80,dark:0|danger:110,warning:120,yellow:40,success:50,blue:80,dark:0','歼世灭尽龙','',243,'灭尽龙衍生','滅盡一刀','灭尽龙太刀','灭尽一刀【绝】',1);

insert into t_weapon values (null,'灭尽一刀【绝】',12,957,0,'','dragon:180','龙封力[大]','67','歼世灭尽龙的太刀。「罪孽深重的人啊，俯首认罪吧」让杀戮之刃斩断所有罪孽。','danger:80,warning:30,yellow:30,success:110,blue:40,white:110,dark:0|danger:80,warning:30,yellow:30,success:110,blue:40,white:110,dark:0','歼世灭尽龙','',243,'灭尽龙衍生','滅盡一刀【絕】','灭尽一刀','',0);
insert into t_weapon values (null,'眩刀【摇】1',3,429,0,'','','','','眩鸟的太刀。经过精心打磨的素材正闪闪发亮。锋利度更上一层的一把刀。','danger:70,warning:50,yellow:80,success:50,dark:150|danger:70,warning:50,yellow:80,success:100,dark:100','风漂龙的鳞','',243,'眩鸟衍生','眩刀【搖】Ⅰ','铁刀3','眩刀【摇】2',0);

insert into t_weapon values (null,'眩刀【摇】2',4,462,0,'','','','','眩鸟的太刀。经过精心打磨的素材正闪闪发亮。锋利度更上一层的一把刀。','danger:60,warning:50,yellow:80,success:60,dark:150|danger:60,warning:50,yellow:80,success:110,dark:100','眩鸟的上鳞','',243,'眩鸟衍生','眩刀【搖】Ⅱ','眩刀【摇】1','眩惑刀【闪】1',0);

insert into t_weapon values (null,'眩惑刀【闪】1',5,528,0,'','thunder:(240)','','68','眩鸟的太刀。经过精心打磨的刀刃，闪烁着令人目眩的寒光。','danger:100,warning:50,yellow:50,success:80,blue:20,dark:100|danger:100,warning:50,yellow:50,success:80,blue:70,dark:50','风漂龙的上鳞','',243,'眩鸟衍生','眩惑刀【閃】Ⅰ','眩刀【摇】2','眩惑刀【闪】2',0);

insert into t_weapon values (null,'眩惑刀【闪】2',6,561,0,'','thunder:(300)','','67','眩鸟的太刀。经过精心打磨的刀刃，闪烁着令人目眩的寒光。','danger:90,warning:50,yellow:50,success:80,blue:30,dark:100|danger:90,warning:50,yellow:50,success:80,blue:80,dark:50','钢的上龙鳞','',243,'眩鸟衍生','眩惑刀【閃】Ⅱ','眩惑刀【闪】1','眩惑刀【闪】3',3);

insert into t_weapon values (null,'眩惑刀【闪】3',6,594,0,'','thunder:(360)','','67','眩鸟的太刀。经过精心打磨的刀刃，闪烁着令人目眩的寒光。','danger:80,warning:50,yellow:60,success:120,blue:40,dark:50|danger:80,warning:50,yellow:60,success:120,blue:50,white:40,dark:0','眩鸟的厚皮','',243,'眩鸟衍生','眩惑刀【閃】Ⅲ','眩惑刀【闪】2','眩惑乱刀【闪光】1',3);

insert into t_weapon values (null,'眩惑乱刀【闪光】1',9,726,0,'','thunder:(450)','','67','眩鸟的太刀。璀璨光辉的夺魂挥斩，在空中划出眩目一闪。','danger:120,warning:30,yellow:30,success:110,blue:40,white:20,dark:50|danger:120,warning:30,yellow:30,success:110,blue:40,white:70,dark:0','冰牙龙','',243,'眩鸟衍生','眩惑亂刀【閃光】Ⅰ','眩惑刀【闪】3','眩惑乱刀【闪光】2|冰牙刀【琥珀】1',0);

insert into t_weapon values (null,'眩惑乱刀【闪光】2',10,858,0,'','thunder:(480)','','67','眩鸟的太刀。璀璨光辉的夺魂挥斩，在空中划出眩目一闪。','danger:90,warning:30,yellow:30,success:110,blue:40,white:50,dark:50|danger:90,warning:30,yellow:30,success:110,blue:40,white:100,dark:0','风漂龙的厚皮','',243,'眩鸟衍生','眩惑亂刀【閃光】Ⅱ','眩惑乱刀【闪光】1','',0);
insert into t_weapon values (null,'冰牙刀【琥珀】1',10,726,0,'+20%','ice:210','','','冰牙龙的太刀。由锋锐寒冷的材料制成之刀，将让猎物冰霜彻骨。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','冰牙龙票','',243,'冰牙龙衍生','冰牙刀【琥珀】Ⅰ','眩惑乱刀【闪光】1','冰牙刀【琥珀】2|亚铎霜锋',0);

insert into t_weapon values (null,'冰牙刀【琥珀】2',10,792,0,'+30%','ice:300','','67','冰牙龙的太刀。由锋锐寒冷的材料制成之刀，将让猎物冰霜彻骨。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','霜翼风漂龙','',243,'冰牙龙衍生','冰牙刀【琥珀】Ⅱ','冰牙刀【琥珀】1','',0);

insert into t_weapon values (null,'亚铎霜锋',11,891,0,'+15%','ice:540','','','霜刃冰牙龙的太刀。周身环绕着刺骨冰气的白银冰刃。此为永霜冻土的守护者之证明。','danger:10,warning:40,yellow:50,success:50,blue:60,white:120,purple:20,dark:50|danger:10,warning:40,yellow:50,success:50,blue:60,white:120,purple:70,dark:0','冰牙龙票','',243,'霜刃冰牙龙衍生改','亞鐸霜鋒','冰牙刀【琥珀】1','',0);
insert into t_weapon values (null,'星空太刀1',2,330,0,'+15%','','','','搔鸟的太刀。刀身采用了轻薄坚固的素材，让任何猎人皆可身轻如燕地行动。','danger:70,warning:70,yellow:30,success:30,dark:200|danger:70,warning:70,yellow:30,success:80,dark:150','雌火龙','',243,'搔鸟衍生','星空太刀Ⅰ','铁刀2','星空太刀2|飞龙刀【绿叶】',0);

insert into t_weapon values (null,'星空太刀2',3,363,0,'+15%','','','','搔鸟的太刀。刀身采用了轻薄坚固的素材，让任何猎人皆可身轻如燕地行动。','danger:80,warning:50,yellow:80,success:40,dark:150|danger:80,warning:50,yellow:80,success:90,dark:100','惨爪龙的爪','',243,'搔鸟衍生','星空太刀Ⅱ','星空太刀1','星空太刀3',0);

insert into t_weapon values (null,'星空太刀3',4,429,0,'+15%','','','','搔鸟的太刀。刀身采用了轻薄坚固的素材，让任何猎人皆可身轻如燕地行动。','danger:60,warning:50,yellow:80,success:60,dark:150|danger:60,warning:50,yellow:80,success:110,dark:100','搔鸟的上鳞','',243,'搔鸟衍生','星空太刀Ⅲ','星空太刀2','星空迅刀1',0);

insert into t_weapon values (null,'星空迅刀1',5,495,0,'+20%','sleep:(210)','','','搔鸟的太刀。可使猎人的行动更加敏捷，将敌人玩弄到咬牙切齿。','danger:110,warning:50,yellow:50,success:80,blue:10,dark:100|danger:110,warning:50,yellow:50,success:80,blue:60,dark:50','爆锤龙','',243,'搔鸟衍生','星空迅刀Ⅰ','星空太刀3','星空迅刀2|爆锤太刀1',0);

insert into t_weapon values (null,'星空迅刀2',6,528,0,'+20%','sleep:(240)','','','搔鸟的太刀。可使猎人的行动更加敏捷，将敌人玩弄到咬牙切齿。','danger:80,warning:50,yellow:50,success:80,blue:40,dark:100|danger:80,warning:50,yellow:50,success:80,blue:90,dark:50','不灭的龙鳞','',243,'搔鸟衍生','星空迅刀Ⅱ','星空迅刀1','星空迅刀3',3);

insert into t_weapon values (null,'星空迅刀3',6,561,0,'+20%','sleep:(270)','','','搔鸟的太刀。可使猎人的行动更加敏捷，将敌人玩弄到咬牙切齿。','danger:80,warning:60,yellow:80,success:80,blue:50,dark:50|danger:80,warning:60,yellow:80,success:80,blue:80,white:20,dark:0','搔鸟的厚皮','',243,'搔鸟衍生','星空迅刀Ⅲ','星空迅刀2','巢穴搭挡1',3);

insert into t_weapon values (null,'巢穴搭挡1',9,693,0,'+25%','sleep:(360)','','','搔鸟的太刀。用更高质量的素材打造而成。能以快到看不见的速度压制猎物。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','迅龙','',243,'搔鸟衍生','巢穴搭擋Ⅰ','星空迅刀3','巢穴搭挡2|隐密配剑',0);

insert into t_weapon values (null,'巢穴搭挡2',10,825,0,'+25%','sleep:(420)','','','搔鸟的太刀。用更高质量的素材打造而成。能以快到看不见的速度压制猎物。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','迅龙','',243,'搔鸟衍生','巢穴搭擋Ⅱ','巢穴搭挡1','',0);
insert into t_weapon values (null,'隐密配剑',10,726,0,'+10%','poison:(360)','','','迅龙的太刀。随着练气现出刀刃的构造，是工房的最高机密。','danger:80,warning:80,yellow:30,success:30,blue:80,white:50,dark:50|danger:80,warning:80,yellow:30,success:30,blue:80,white:100,dark:0','雷颚龙','',243,'迅龙衍生','隱密配劍','巢穴搭挡1','隐密配剑·改',0);

insert into t_weapon values (null,'隐密配剑·改',10,759,0,'+15%','poison:(450)','','','迅龙的太刀。随着练气现出刀刃的构造，是工房的最高机密。','danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:20,dark:50|danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:70,dark:0','雾瘴尸套龙','',243,'迅龙衍生','隱密配劍‧改','隐密配剑','夜刀【月影】',0);

insert into t_weapon values (null,'夜刀【月影】',11,792,0,'+20%','poison:(540)','','','迅龙的太刀。随着练气现出刀刃的构造，是工房的最高机密。','danger:140,warning:20,yellow:20,success:70,blue:40,white:30,purple:30,dark:50|danger:140,warning:20,yellow:20,success:70,blue:40,white:30,purple:80,dark:0','雾瘴尸套龙','',243,'迅龙衍生','夜刀【月影】','隐密配剑·改','',0);
insert into t_weapon values (null,'爆锤太刀1',6,594,25,'-10%','fire:90','','67','爆锤龙的太刀。可活用一瞬间增加的重量，并连续发出势不可挡的强力攻击。','danger:100,warning:50,yellow:50,success:80,blue:20,dark:100|danger:100,warning:50,yellow:50,success:80,blue:70,dark:50','狱炎的龙鳞','',243,'爆锤龙衍生','爆鎚太刀Ⅰ','星空迅刀1','爆锤太刀2',3);

insert into t_weapon values (null,'爆锤太刀2',7,660,30,'-10%','fire:120','','67,67','爆锤龙的太刀。可活用一瞬间增加的重量，并连续发出势不可挡的强力攻击。','danger:90,warning:50,yellow:50,success:80,blue:80,dark:50|danger:90,warning:50,yellow:50,success:80,blue:130,dark:0','斩龙','',243,'爆锤龙衍生','爆鎚太刀Ⅱ','爆锤太刀1','重刃爆锤1|斩龙宝刀1',2);

insert into t_weapon values (null,'重刃爆锤1',10,792,35,'-10%','fire:210','','73,67','爆锤龙的太刀。硬度超常，重量非凡。一闪能将大地为之两断。','danger:110,warning:50,yellow:50,success:80,blue:60,dark:50|danger:110,warning:50,yellow:50,success:80,blue:110,dark:0','硫斩龙','',243,'爆锤龙衍生','重刃爆鎚Ⅰ','爆锤太刀2','重刃爆锤2',0);

insert into t_weapon values (null,'重刃爆锤2',10,957,35,'-10%','fire:240','','73,67','爆锤龙的太刀。硬度超常，重量非凡。一闪能将大地为之两断。','danger:100,warning:50,yellow:50,success:80,blue:70,dark:50|danger:100,warning:50,yellow:50,success:80,blue:120,dark:0','硫斩龙','',243,'爆锤龙衍生','重刃爆鎚Ⅱ','重刃爆锤1','',0);
insert into t_weapon values (null,'斩龙宝刀1',10,759,0,'','fire:240','','67','斩龙的太刀。暗藏之火呼应着猎人的斗志，将猎物的灵魂也燃烧殆尽。','danger:100,warning:80,yellow:30,success:30,blue:80,white:30,dark:50|danger:100,warning:80,yellow:30,success:30,blue:80,white:80,dark:0','凶爪龙','',243,'斩龙衍生','斬龍寶刀Ⅰ','爆锤太刀2','斩龙宝刀2',0);

insert into t_weapon values (null,'斩龙宝刀2',10,825,0,'','fire:270','','67,67','斩龙的太刀。暗藏之火呼应着猎人的斗志，将猎物的灵魂也燃烧殆尽。','danger:130,warning:30,yellow:30,success:60,blue:50,white:50,dark:50|danger:130,warning:30,yellow:30,success:60,blue:50,white:70,purple:30,dark:0','凶爪龙','',243,'斩龙衍生','斬龍寶刀Ⅱ','斩龙宝刀1','',0);


insert into t_weapon values (null,'飞龙刀【绿叶】',3,363,0,'+10%','poison:240','','','雌火龙的太刀。深绿色的飞龙刀，锋利与威力兼具的上等利刃。','danger:90,warning:50,yellow:80,success:30,dark:150|danger:90,warning:50,yellow:80,success:80,dark:100','火龙','',243,'雌火龙衍生','飛龍刀【綠葉】','星空太刀1','飞龙刀【翠】|飞龙刀【红叶】',0);

insert into t_weapon values (null,'飞龙刀【翠】',5,495,0,'+10%','poison:270','','67','雌火龙的太刀。深绿色的飞龙刀，锋利与威力兼具的上等利刃。','danger:110,warning:50,yellow:50,success:80,blue:10,dark:100|danger:110,warning:50,yellow:50,success:80,blue:60,dark:50','渴望的黑创','',243,'雌火龙衍生','飛龍刀【翠】','飞龙刀【绿叶】','飞龙刀【葵】',0);

insert into t_weapon values (null,'飞龙刀【葵】',7,627,0,'+10%','poison:330','','67','雌火龙的太刀。深绿色的飞龙刀，锋利与威力兼具的上等利刃。','danger:80,warning:60,yellow:60,success:100,blue:50,dark:50|danger:80,warning:60,yellow:60,success:100,blue:70,white:30,dark:0','雌火龙的重壳','',243,'雌火龙衍生','飛龍刀【葵】','飞龙刀【翠】','飞龙刀【樱花】',2);

insert into t_weapon values (null,'飞龙刀【樱花】',9,759,0,'+10%','poison:360','','67','樱火龙的太刀。樱色的飞龙刀。缭乱太刀将绘出鲜艳轨迹。','danger:90,warning:100,yellow:40,success:50,blue:70,dark:50|danger:90,warning:100,yellow:40,success:50,blue:70,white:50,dark:0','刚龙骨','',243,'雌火龙衍生','飛龍刀【櫻花】','飞龙刀【葵】','飞龙刀【樱花】·改',0);

insert into t_weapon values (null,'飞龙刀【樱花】·改',10,858,0,'+10%','poison:390','','67','樱火龙的太刀。樱色的飞龙刀。缭乱太刀将绘出鲜艳轨迹。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','金火龙','',243,'雌火龙衍生','飛龍刀【櫻花】‧改','飞龙刀【樱花】','飞龙刀【月】',0);

insert into t_weapon values (null,'飞龙刀【月】',12,957,0,'+10%','poison:420','','67','金火龙的太刀。压制了黄金女王之证明。一挥斩断天地，持续发出璀璨光辉。','danger:70,warning:80,yellow:30,success:30,blue:80,white:60,dark:50|danger:70,warning:80,yellow:30,success:30,blue:80,white:110,dark:0','金火龙','',243,'雌火龙衍生','飛龍刀【月】','飞龙刀【樱花】·改','',0);
insert into t_weapon values (null,'飞龙刀【红叶】',4,396,0,'+15%','fire:150','','','火龙的太刀。朱红而强韧的刀刃所挥出的每一次斩击，都能让对手受到热波与爆炎的洗礼。','danger:80,warning:50,yellow:80,success:40,dark:150|danger:80,warning:50,yellow:80,success:90,dark:100','火龙的上鳞','',243,'火龙衍生','飛龍刀【紅葉】','飞龙刀【绿叶】','飞龙刀【朱】',0);

insert into t_weapon values (null,'飞龙刀【朱】',6,528,0,'+15%','fire:180','','67','火龙的太刀。朱红而强韧的刀刃所挥出的每一次斩击，都能让对手受到热波与爆炎的洗礼。','danger:110,warning:50,yellow:50,success:80,blue:10,dark:100|danger:110,warning:50,yellow:50,success:80,blue:60,dark:50','苍火龙','',243,'火龙衍生','飛龍刀【朱】','飞龙刀【红叶】','飞龙刀【苍】',3);
insert into t_weapon values (null,'飞龙刀【苍】',7,561,0,'+15%','fire:210','','67','苍火龙的太刀。蕴藏着苍之王灵魂的名刀。据说它的一击可焚烧天空、撕裂大地。','danger:100,warning:60,yellow:80,success:80,blue:30,dark:50|danger:100,warning:60,yellow:80,success:80,blue:60,white:20,dark:0','狱炎的龙鳞','',243,'苍火龙衍生','飛龍刀【蒼】','飞龙刀【朱】','飞龙刀【蓝染】',2);

insert into t_weapon values (null,'飞龙刀【蓝染】',8,627,0,'+15%','fire:240','','67','苍火龙的太刀。蕴藏着苍之王灵魂的名刀。据说它的一击可焚烧天空、撕裂大地。','danger:70,warning:50,yellow:60,success:120,blue:50,dark:50|danger:70,warning:50,yellow:60,success:120,blue:60,white:40,dark:0','火龙的重壳','',243,'苍火龙衍生','飛龍刀【藍染】','飞龙刀【苍】','飞龙刀【蓝染】·改',1);

insert into t_weapon values (null,'飞龙刀【蓝染】·改',10,726,0,'+15%','fire:300','','67','苍火龙的太刀。蕴藏着苍之王灵魂的名刀。据说它的一击可焚烧天空、撕裂大地。','danger:90,warning:100,yellow:40,success:50,blue:70,dark:50|danger:90,warning:100,yellow:40,success:50,blue:70,white:50,dark:0','苍火龙的重壳','',243,'苍火龙衍生','飛龍刀【藍染】‧改','飞龙刀【蓝染】','飞龙刀【苍天】',0);

insert into t_weapon values (null,'飞龙刀【苍天】',10,792,0,'+20%','fire:330','','67','苍火龙的太刀。蕴藏着苍之王灵魂的名刀。据说它的一击可焚烧天空、撕裂大地。','danger:100,warning:80,yellow:30,success:30,blue:80,white:30,dark:50|danger:100,warning:80,yellow:30,success:30,blue:80,white:80,dark:0','银火龙','',243,'苍火龙衍生','飛龍刀【蒼天】','飞龙刀【蓝染】·改','飞龙刀【银】',0);

insert into t_weapon values (null,'飞龙刀【银】',12,891,0,'+20%','fire:420','','68','苍火龙的太刀。对比刀身冷冽的锋芒，带有令对手骨头化为焦炭之灼热。','danger:130,warning:30,yellow:30,success:60,blue:50,white:50,dark:50|danger:130,warning:30,yellow:30,success:60,blue:50,white:70,purple:30,dark:0','银火龙','',243,'苍火龙衍生','飛龍刀【銀】','飞龙刀【苍天】','',0);

insert into t_weapon values (null,'骨制弯刀1',1,297,0,'','','','','以已收集的骸骨加工制成的太刀。虽粗糙却坚固易用，推荐初出茅庐的新手猎人使用。','danger:100,warning:60,yellow:40,dark:200|danger:100,warning:60,yellow:80,success:10,dark:150','','',243,'骸骨素材衍生','骨製彎刀Ⅰ','','骨制弯刀2',0);

insert into t_weapon values (null,'骨制弯刀2',1,330,0,'','','','','以已收集的骸骨加工制成的太刀。虽粗糙却坚固易用，推荐初出茅庐的新手猎人使用。','danger:90,warning:50,yellow:60,dark:200|danger:90,warning:50,yellow:80,success:30,dark:150','飞雷龙','',243,'骸骨素材衍生','骨製彎刀Ⅱ','骨制弯刀1','骨制弯刀3|泥鱼龙弯刀1|脉冲弯刀1',0);

insert into t_weapon values (null,'骨制弯刀3',2,396,0,'','','','','以已收集的骸骨加工制成的太刀。虽粗糙却坚固易用，推荐初出茅庐的新手猎人使用。','danger:70,warning:60,yellow:60,success:10,dark:200|danger:70,warning:60,yellow:60,success:60,dark:150','蛮颚龙','',243,'骸骨素材衍生','骨製彎刀Ⅲ','骨制弯刀2','硬骨弯刀1|火炎弯刀1',0);

insert into t_weapon values (null,'硬骨弯刀1',3,429,0,'','','','','挑选坚硬骸骨再加以强固制成的太刀。兼具易用性和强大的破坏力。','danger:130,warning:70,yellow:30,success:20,dark:150|danger:130,warning:70,yellow:30,success:70,dark:100','上龙骨','',243,'骸骨素材衍生','硬骨彎刀Ⅰ','骨制弯刀3','硬骨弯刀2',0);

insert into t_weapon values (null,'硬骨弯刀2',4,495,0,'','','','','挑选坚硬骸骨再加以强固制成的太刀。兼具易用性和强大的破坏力。','danger:110,warning:70,yellow:30,success:40,dark:150|danger:110,warning:70,yellow:30,success:90,dark:100','尖龙骨','',243,'骸骨素材衍生','硬骨彎刀Ⅱ','硬骨弯刀1','硬骨弯刀3',0);

insert into t_weapon values (null,'硬骨弯刀3',5,528,0,'','sleep:(210)','','67','挑选坚硬骸骨再加以强固制成的太刀。兼具易用性和强大的破坏力。','danger:140,warning:70,yellow:30,success:60,dark:100|danger:140,warning:70,yellow:30,success:100,blue:10,dark:50','爆鳞龙','',243,'骸骨素材衍生','硬骨彎刀Ⅲ','硬骨弯刀2','骨镰1|爆鳞大刀',0);

insert into t_weapon values (null,'骨镰1',6,561,10,'','sleep:(240)','','68','将骸骨反复打磨制成的的太刀。充满野性的必杀连击，据说连巨大的岩石都能轻易一刀两断。','danger:100,warning:100,yellow:40,success:40,blue:20,dark:100|danger:100,warning:100,yellow:40,success:40,blue:70,dark:50','古龙骨','',243,'骸骨素材衍生','骨鐮Ⅰ','硬骨弯刀3','骨镰2',3);

insert into t_weapon values (null,'骨镰2',6,627,10,'','sleep:(270)','','67','将骸骨反复打磨制成的的太刀。充满野性的必杀连击，据说连巨大的岩石都能轻易一刀两断。','danger:100,warning:120,yellow:40,success:50,blue:40,dark:50|danger:100,warning:120,yellow:40,success:50,blue:90,dark:0','粗活就交给猛牛龙','',243,'骸骨素材衍生','骨鐮Ⅱ','骨镰1','大地镰状剑1',3);

insert into t_weapon values (null,'大地镰状剑1',9,759,35,'','sleep:(300)','','67','以稀有贵重的龙骨打造之太刀。洗炼的外观设计，蕴藏能劈断钢铁的强大破坏力。','danger:100,warning:100,yellow:40,success:50,blue:60,dark:50|danger:100,warning:100,yellow:40,success:50,blue:60,white:50,dark:0','轰龙','',243,'骸骨素材衍生','大地鐮狀劍Ⅰ','骨镰2','大地镰状剑2|一虎刀',0);

insert into t_weapon values (null,'大地镰状剑2',10,825,35,'','sleep:(300)','','67','以稀有贵重的龙骨打造之太刀。洗炼的外观设计，蕴藏能劈断钢铁的强大破坏力。','danger:90,warning:100,yellow:40,success:50,blue:70,dark:50|danger:90,warning:100,yellow:40,success:50,blue:70,white:50,dark:0','冰呪龙','',243,'骸骨素材衍生','大地鐮狀劍Ⅱ','大地镰状剑1','大地镰状剑3|严冰锋刃',0);

insert into t_weapon values (null,'大地镰状剑3',11,924,35,'','sleep:(300)','','67','以稀有贵重的龙骨打造之太刀。洗炼的外观设计，蕴藏能劈断钢铁的强大破坏力。','danger:80,warning:100,yellow:40,success:50,blue:80,dark:50|danger:80,warning:100,yellow:40,success:50,blue:80,white:50,dark:0','太古龙骨','',243,'骸骨素材衍生','大地鐮狀劍Ⅲ','大地镰状剑2','',0);
insert into t_weapon values (null,'严冰锋刃',11,858,0,'','ice:240','','73','冰呪龙的太刀。极寒之刃将苦痛的哀号瞬间冰封，只留下永恒的寂静。','danger:150,warning:30,yellow:30,success:60,blue:50,white:30,dark:50|danger:150,warning:30,yellow:30,success:60,blue:50,white:30,purple:50,dark:0','天地煌啼龙','',243,'冰呪龙衍生','嚴冰鋒刃','大地镰状剑2','冰灵芒刃',0);

insert into t_weapon values (null,'冰灵芒刃',12,891,0,'','ice:270','','73','冰呪龙的太刀。极寒之刃将苦痛的哀号瞬间冰封，只留下永恒的寂静。','danger:140,warning:30,yellow:30,success:60,blue:50,white:40,dark:50|danger:140,warning:30,yellow:30,success:60,blue:50,white:40,purple:50,dark:0','天地煌啼龙','',243,'冰呪龙衍生','冰靈芒刃','严冰锋刃','',0);
insert into t_weapon values (null,'一虎刀',10,825,0,'-20%','blast:(210)','','','轰龙的太刀。并排在刀刃两侧之牙，能让猎物受到无法回复之伤害。','danger:80,warning:30,yellow:30,success:110,blue:40,white:60,dark:50|danger:80,warning:30,yellow:30,success:110,blue:40,white:110,dark:0','黑轰龙','',243,'轰龙衍生','一虎刀','大地镰状剑1','一虎刀·改|吼虎刀',0);

insert into t_weapon values (null,'一虎刀·改',10,891,0,'-20%','blast:(240)','','','轰龙的太刀。并排在刀刃两侧之牙，能让猎物受到无法回复之伤害。','danger:70,warning:30,yellow:30,success:110,blue:40,white:70,dark:50|danger:70,warning:30,yellow:30,success:110,blue:40,white:120,dark:0','钢龙的重壳','',243,'轰龙衍生','一虎刀‧改','一虎刀','一虎刀【饿刃】',0);

insert into t_weapon values (null,'一虎刀【饿刃】',11,924,0,'-20%','blast:(330)','','','轰龙的太刀。并排在刀刃两侧之牙，能让猎物受到无法回复之伤害。','danger:60,warning:30,yellow:30,success:110,blue:40,white:80,dark:50|danger:60,warning:30,yellow:30,success:110,blue:40,white:130,dark:0','钢龙的重壳','',243,'轰龙衍生','一虎刀【餓刃】','一虎刀·改','',0);
insert into t_weapon values (null,'吼虎刀',11,924,0,'-30%','sleep:(240)','','','黑轰龙的太刀。凶恶之牙瞄准着猎物，并散发妖异的光芒。','danger:100,warning:20,yellow:30,success:90,blue:90,white:20,dark:50|danger:100,warning:20,yellow:30,success:90,blue:90,white:30,purple:40,dark:0','历战的黑龙颚','',243,'黑轰龙衍生','吼虎刀','一虎刀','吼虎刀【饿咬】',0);

insert into t_weapon values (null,'吼虎刀【饿咬】',12,957,0,'-30%','sleep:(390)','','','黑轰龙的太刀。凶恶之牙瞄准着猎物，并散发妖异的光芒。','danger:90,warning:20,yellow:30,success:90,blue:90,white:30,dark:50|danger:90,warning:20,yellow:30,success:90,blue:90,white:40,purple:40,dark:0','历战的黑龙颚','',243,'黑轰龙衍生','吼虎刀【餓咬】','吼虎刀','',0);
insert into t_weapon values (null,'爆鳞大刀',6,561,0,'-10%','blast:150','','67,67','爆鳞龙的太刀。闪闪发光的银色鳞片正如同暴徒的先锋一般。在爆击同时可放出舍身一击。','danger:100,warning:100,yellow:40,success:40,blue:20,dark:100|danger:100,warning:100,yellow:40,success:40,blue:70,dark:50','收束之地','',243,'爆鳞龙衍生','爆鱗大刀','硬骨弯刀3','爆鳞刀赤红利刃',3);

insert into t_weapon values (null,'爆鳞刀赤红利刃',8,660,0,'-10%','blast:210','','67,67','爆鳞龙的太刀。闪闪发光的银色鳞片正如同暴徒的先锋一般。在爆击同时可放出舍身一击。','danger:60,warning:120,yellow:80,success:60,blue:30,dark:50|danger:60,warning:120,yellow:80,success:60,blue:30,white:50,dark:0','红莲爆鳞龙','',243,'爆鳞龙衍生','爆鱗刀赤紅利刃','爆鳞大刀','爆炎大刀',1);

insert into t_weapon values (null,'爆炎大刀',11,792,0,'-10%','blast:240','','67,67','红莲爆鳞龙的太刀。殷红炽热之鳞为我之战意。划破沉睡，揭开狂宴的序幕。','danger:150,warning:30,yellow:30,success:60,blue:50,white:30,dark:50|danger:150,warning:30,yellow:30,success:60,blue:50,white:30,purple:50,dark:0','天地煌啼龙','',243,'爆鳞龙衍生','爆炎大刀','爆鳞刀赤红利刃','炸裂迸发爆炎刀',0);

insert into t_weapon values (null,'炸裂迸发爆炎刀',12,858,0,'-10%','blast:300','','67,67','红莲爆鳞龙的太刀。殷红炽热之鳞为我之战意。划破沉睡，揭开狂宴的序幕。','danger:140,warning:30,yellow:30,success:60,blue:50,white:40,dark:50|danger:140,warning:30,yellow:30,success:60,blue:50,white:40,purple:50,dark:0','天地煌啼龙','',243,'爆鳞龙衍生','炸裂迸發爆炎刀','爆炎大刀','',0);
insert into t_weapon values (null,'火炎弯刀1',3,462,0,'-20%','fire:150','','','蛮颚龙的太刀。缠卷了因受到灼热吐息而获得强化的毛皮来进行补强。','danger:130,warning:70,yellow:30,success:20,dark:150|danger:130,warning:70,yellow:30,success:70,dark:100','火龙的骨髓','',243,'蛮颚龙衍生','火焰彎刀Ⅰ','骨制弯刀3','火炎弯刀2',0);

insert into t_weapon values (null,'火炎弯刀2',4,528,0,'-20%','fire:210','','','蛮颚龙的太刀。缠卷了因受到灼热吐息而获得强化的毛皮来进行补强。','danger:120,warning:70,yellow:30,success:30,dark:150|danger:120,warning:70,yellow:30,success:80,dark:100','蛮颚龙的上鳞','',243,'蛮颚龙衍生','火焰彎刀Ⅱ','火炎弯刀1','蛮颚龙偃月刀1',0);

insert into t_weapon values (null,'蛮颚龙偃月刀1',5,594,0,'-20%','fire:270','','','蛮颚龙的太刀。能将侵入周身的一切燃烧殆尽的灼热之刃正向猎物席卷而去。','danger:140,warning:70,yellow:30,success:60,dark:100|danger:140,warning:70,yellow:30,success:100,blue:10,dark:50','火龙的上鳞','',243,'蛮颚龙衍生','蠻顎龍偃月刀Ⅰ','火炎弯刀2','蛮颚龙偃月刀2',0);

insert into t_weapon values (null,'蛮颚龙偃月刀2',6,660,0,'-20%','fire:330','','','蛮颚龙的太刀。能将侵入周身的一切燃烧殆尽的灼热之刃正向猎物席卷而去。','danger:100,warning:100,yellow:40,success:40,blue:20,dark:100|danger:100,warning:100,yellow:40,success:40,blue:70,dark:50','狱炎的龙鳞','',243,'蛮颚龙衍生','蠻顎龍偃月刀Ⅱ','蛮颚龙偃月刀1','蛮颚龙偃月刀3',3);

insert into t_weapon values (null,'蛮颚龙偃月刀3',6,693,0,'-20%','fire:390','','','蛮颚龙的太刀。能将侵入周身的一切燃烧殆尽的灼热之刃正向猎物席卷而去。','danger:110,warning:120,yellow:40,success:50,blue:30,dark:50|danger:110,warning:120,yellow:40,success:50,blue:80,dark:0','蛮颚龙的厚毛皮','',243,'蛮颚龙衍生','蠻顎龍偃月刀Ⅲ','蛮颚龙偃月刀2','蛮颚龙之激牙1',3);

insert into t_weapon values (null,'蛮颚龙之激牙1',9,759,0,'-20%','fire:480','','','蛮颚龙的太刀。到手的猎物定难逃生天，宛如烈火般的执念灌注在刀光之中。','danger:80,warning:100,yellow:40,success:50,blue:80,dark:50|danger:80,warning:100,yellow:40,success:50,blue:80,white:50,dark:0','雷颚龙','',243,'蛮颚龙衍生','蠻顎龍之激牙Ⅰ','蛮颚龙偃月刀3','蛮颚龙之激牙2|崩坏雷颚1',0);

insert into t_weapon values (null,'蛮颚龙之激牙2',10,891,0,'-20%','fire:600','','','蛮颚龙的太刀。到手的猎物定难逃生天，宛如烈火般的执念灌注在刀光之中。','danger:80,warning:100,yellow:40,success:50,blue:80,dark:50|danger:80,warning:100,yellow:40,success:50,blue:80,white:50,dark:0','苍火龙的重壳','',243,'蛮颚龙衍生','蠻顎龍之激牙Ⅱ','蛮颚龙之激牙1','',0);
insert into t_weapon values (null,'崩坏雷颚1',10,792,0,'+10%','thunder:240','','','雷颚龙的太刀。封印着爆走的雷霆之力，难以驾驭且破坏力极强。','danger:80,warning:100,yellow:40,success:50,blue:80,dark:50|danger:80,warning:100,yellow:40,success:50,blue:80,white:50,dark:0','雷颚龙','',243,'雷颚龙衍生','崩壞雷顎Ⅰ','蛮颚龙之激牙1','崩坏雷颚2',0);

insert into t_weapon values (null,'崩坏雷颚2',10,825,0,'+20%','thunder:330','','67','雷颚龙的太刀。封印着爆走的雷霆之力，难以驾驭且破坏力极强。','danger:80,warning:100,yellow:40,success:50,blue:80,dark:50|danger:80,warning:100,yellow:40,success:50,blue:80,white:50,dark:0','雷颚龙','',243,'雷颚龙衍生','崩壞雷顎Ⅱ','崩坏雷颚1','',0);
insert into t_weapon values (null,'泥鱼龙弯刀1',2,396,0,'','water:150','','','泥鱼龙的太刀。附加了像泥土般的硬质素材，并以充满野性的外观与超群的强度而着称。','danger:80,warning:70,yellow:30,success:20,dark:200|danger:80,warning:70,yellow:30,success:70,dark:150','大痹贼龙的皮','',243,'泥鱼龙衍生','泥岩龍彎刀Ⅰ','骨制弯刀2','泥鱼龙弯刀2',0);

insert into t_weapon values (null,'泥鱼龙弯刀2',3,429,0,'','water:180','','','泥鱼龙的太刀。附加了像泥土般的硬质素材，并以充满野性的外观与超群的强度而着称。','danger:120,warning:70,yellow:30,success:30,dark:150|danger:120,warning:70,yellow:30,success:80,dark:100','上龙骨','',243,'泥鱼龙衍生','泥岩龍彎刀Ⅱ','泥鱼龙弯刀1','泥鱼龙弯刀3',0);

insert into t_weapon values (null,'泥鱼龙弯刀3',4,462,0,'','water:210','','','泥鱼龙的太刀。附加了像泥土般的硬质素材，并以充满野性的外观与超群的强度而着称。','danger:110,warning:70,yellow:30,success:40,dark:150|danger:110,warning:70,yellow:30,success:90,dark:100','泥鱼龙的上鳞','',243,'泥鱼龙衍生','泥岩龍彎刀Ⅲ','泥鱼龙弯刀2','深土太刀1',0);

insert into t_weapon values (null,'深土太刀1',5,495,0,'','water:240','','67','泥鱼龙的太刀。其猛烈的斩击无与伦比，据说能够将猎物如草芥般撕裂。','danger:140,warning:70,yellow:30,success:60,dark:100|danger:140,warning:70,yellow:30,success:100,blue:10,dark:50','坚龙骨','',243,'泥鱼龙衍生','深土太刀Ⅰ','泥鱼龙弯刀3','深土太刀2',0);

insert into t_weapon values (null,'深土太刀2',6,561,0,'','water:300','','68','泥鱼龙的太刀。其猛烈的斩击无与伦比，据说能够将猎物如草芥般撕裂。','danger:110,warning:100,yellow:40,success:40,blue:10,dark:100|danger:110,warning:100,yellow:40,success:40,blue:60,dark:50','尸套龙','',243,'泥鱼龙衍生','深土太刀Ⅱ','深土太刀1','深土太刀3|尸套龙太刀1',3);

insert into t_weapon values (null,'深土太刀3',6,627,0,'','water:360','','67','泥鱼龙的太刀。其猛烈的斩击无与伦比，据说能够将猎物如草芥般撕裂。','danger:170,warning:100,yellow:30,success:30,blue:20,dark:50|danger:170,warning:100,yellow:30,success:30,blue:40,white:30,dark:0','猛牛龙','',243,'泥鱼龙衍生','深土太刀Ⅲ','深土太刀2','深土漫滩1|巨牛大太刀1',3);

insert into t_weapon values (null,'深土漫滩1',9,759,0,'','water:390','','67,67','泥鱼龙的太刀。由纯洁的泥土所打造，具有肆虐万物的猛烈破坏力。','danger:100,warning:100,yellow:40,success:50,blue:60,dark:50|danger:100,warning:100,yellow:40,success:50,blue:60,white:50,dark:0','重龙骨','',243,'泥鱼龙衍生','深土漫灘Ⅰ','深土太刀3','深土漫滩2',0);

insert into t_weapon values (null,'深土漫滩2',10,858,0,'','water:420','','67,67','泥鱼龙的太刀。由纯洁的泥土所打造，具有肆虐万物的猛烈破坏力。','danger:100,warning:100,yellow:40,success:50,blue:60,dark:50|danger:100,warning:100,yellow:40,success:50,blue:60,white:50,dark:0','重龙骨','',243,'泥鱼龙衍生','深土漫灘Ⅱ','深土漫滩1','',0);
insert into t_weapon values (null,'巨牛大太刀1',9,825,0,'','ice:(330)','','73','猛牛龙的太刀。雄浑豪迈的毛皮，象征着泰然自若与勇猛果敢的气度。','danger:90,warning:50,yellow:50,success:80,blue:80,dark:50|danger:90,warning:50,yellow:50,success:80,blue:130,dark:0','刚龙骨','',243,'猛牛龙衍生','巨牛大太刀Ⅰ','深土太刀3','巨牛大太刀2',0);

insert into t_weapon values (null,'巨牛大太刀2',10,924,0,'','ice:(510)','','73','猛牛龙的太刀。雄浑豪迈的毛皮，象征着泰然自若与勇猛果敢的气度。','danger:90,warning:50,yellow:50,success:80,blue:80,dark:50|danger:90,warning:50,yellow:50,success:80,blue:130,dark:0','刚龙骨','',243,'猛牛龙衍生','巨牛大太刀Ⅱ','巨牛大太刀1','',0);
insert into t_weapon values (null,'尸套龙太刀1',7,627,0,'','dragon:210','龙封力[中]','68','尸套龙的太刀。蕴藏着来自彼岸之力的一击，正是心存死志之人所渴求的解脱。','danger:160,warning:100,yellow:30,success:30,blue:30,dark:50|danger:160,warning:100,yellow:30,success:30,blue:50,white:30,dark:0','收束之地','',243,'尸套龙衍生','屍套龍太刀Ⅰ','深土太刀2','尸套龙太刀2',2);

insert into t_weapon values (null,'尸套龙太刀2',7,660,0,'','dragon:270','龙封力[中]','68','尸套龙的太刀。蕴藏着来自彼岸之力的一击，正是心存死志之人所渴求的解脱。','danger:200,warning:70,yellow:20,success:20,blue:40,dark:50|danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0','硫斩龙','',243,'尸套龙衍生','屍套龍太刀Ⅱ','尸套龙太刀1','死灭帝侯尸刀|罪罚偃月刀1',2);

insert into t_weapon values (null,'死灭帝侯尸刀',11,825,0,'','dragon:480','龙封力[中]','67,68','雾瘴尸套龙的太刀。冥界之声，嘲笑戏弄。不朽之锋，索命无偿。','danger:80,warning:80,yellow:30,success:30,blue:80,white:50,dark:50|danger:80,warning:80,yellow:30,success:30,blue:80,white:100,dark:0','雾瘴尸套龙','',243,'尸套龙衍生','死滅帝侯屍刀','尸套龙太刀2','',0);
insert into t_weapon values (null,'罪罚偃月刀1',10,891,0,'','paralysis:(360)','','73','硫斩龙的太刀。攻击后刀刃将渗出强酸，从内部伤害与削弱猎物。','danger:160,warning:100,yellow:30,success:30,blue:30,dark:50|danger:160,warning:100,yellow:30,success:30,blue:50,white:30,dark:0','雾瘴尸套龙','',243,'硫斩龙衍生','罪罰偃月刀Ⅰ','尸套龙太刀2','罪罚偃月刀2',0);

insert into t_weapon values (null,'罪罚偃月刀2',11,957,0,'','paralysis:(390)','','73','硫斩龙的太刀。攻击后刀刃将渗出强酸，从内部伤害与削弱猎物。','danger:60,warning:50,yellow:110,success:90,blue:40,dark:50|danger:60,warning:50,yellow:110,success:90,blue:60,white:20,purple:10,dark:0','雾瘴尸套龙','',243,'硫斩龙衍生','罪罰偃月刀Ⅱ','罪罚偃月刀1','',0);
insert into t_weapon values (null,'脉冲弯刀1',2,363,0,'+10%','thunder:120','','','飞雷龙的太刀。缠绕于武器上的纯白毛束，因静电的缘故经常处于倒立的状态。','danger:60,warning:70,yellow:30,success:40,dark:200|danger:60,warning:70,yellow:30,success:90,dark:150','巨甲虫','',243,'飞雷龙衍生','脈衝彎刀Ⅰ','骨制弯刀2','脉冲弯刀2|黑色弯刀1',0);

insert into t_weapon values (null,'脉冲弯刀2',3,396,0,'+10%','thunder:150','','','飞雷龙的太刀。缠绕于武器上的纯白毛束，因静电的缘故经常处于倒立的状态。','danger:100,warning:70,yellow:30,success:50,dark:150|danger:100,warning:70,yellow:30,success:100,dark:100','风漂龙','',243,'飞雷龙衍生','脈衝彎刀Ⅱ','脉冲弯刀1','脉冲弯刀3|优雅弯刀1',0);

insert into t_weapon values (null,'脉冲弯刀3',4,462,0,'+10%','thunder:180','','','飞雷龙的太刀。缠绕于武器上的纯白毛束，因静电的缘故经常处于倒立的状态。','danger:90,warning:70,yellow:30,success:60,dark:150|danger:90,warning:70,yellow:30,success:110,dark:100','飞雷龙的上鳞','',243,'飞雷龙衍生','脈衝彎刀Ⅲ','脉冲弯刀2','飞雷龙之牙1',0);

insert into t_weapon values (null,'飞雷龙之牙1',5,528,0,'+15%','thunder:210','','67','飞雷龙的太刀。从毛束所释放出的电击可确实地将猎物弱化。','danger:100,warning:100,yellow:40,success:40,blue:20,dark:100|danger:100,warning:100,yellow:40,success:40,blue:70,dark:50','角龙的坚壳','',243,'飞雷龙衍生','飛雷龍之牙Ⅰ','脉冲弯刀3','飞雷龙之牙2',0);

insert into t_weapon values (null,'飞雷龙之牙2',6,561,0,'+15%','thunder:240','','67','飞雷龙的太刀。从毛束所释放出的电击可确实地将猎物弱化。','danger:90,warning:100,yellow:40,success:40,blue:30,dark:100|danger:90,warning:100,yellow:40,success:40,blue:80,dark:50','不灭的龙鳞','',243,'飞雷龙衍生','飛雷龍之牙Ⅱ','飞雷龙之牙1','飞雷龙之牙3',3);

insert into t_weapon values (null,'飞雷龙之牙3',6,594,0,'+15%','thunder:270','','67','飞雷龙的太刀。从毛束所释放出的电击可确实地将猎物弱化。','danger:150,warning:100,yellow:30,success:30,blue:40,dark:50|danger:150,warning:100,yellow:30,success:30,blue:60,white:30,dark:0','飞雷龙的厚毛皮','',243,'飞雷龙衍生','飛雷龍之牙Ⅲ','飞雷龙之牙2','飞雷龙大刀1',3);

insert into t_weapon values (null,'飞雷龙大刀1',9,693,0,'+15%','thunder:450','','67','飞雷龙的太刀。迸发四射的电光，在强者手中愈显肆虐威势。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','痹毒龙','',243,'飞雷龙衍生','飛雷龍大刀Ⅰ','飞雷龙之牙3','飞雷龙大刀2|朱赤麻痹牙1',0);

insert into t_weapon values (null,'飞雷龙大刀2',10,759,0,'+15%','thunder:510','','67','飞雷龙的太刀。迸发四射的电光，在强者手中愈显肆虐威势。','danger:130,warning:30,yellow:90,success:30,blue:30,white:40,dark:50|danger:130,warning:30,yellow:90,success:30,blue:30,white:70,purple:20,dark:0','惨爪龙的强硬筋','',243,'飞雷龙衍生','飛雷龍大刀Ⅱ','飞雷龙大刀1','',0);
insert into t_weapon values (null,'朱赤麻痹牙1',9,759,0,'+15%','paralysis:210','','67','痹毒龙的太刀。以资深工匠才会运用的危险素材打造，散发恐怖美感的逸品。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','硫斩龙','',243,'痹毒龙衍生','朱赤麻痹牙Ⅰ','飞雷龙大刀1','朱赤麻痹牙2',0);

insert into t_weapon values (null,'朱赤麻痹牙2',10,825,0,'+15%','paralysis:240','','67,67','痹毒龙的太刀。以资深工匠才会运用的危险素材打造，散发恐怖美感的逸品。','danger:130,warning:30,yellow:30,success:60,blue:50,white:50,dark:50|danger:130,warning:30,yellow:30,success:60,blue:50,white:70,purple:30,dark:0','硫斩龙','',243,'痹毒龙衍生','朱赤麻痹牙Ⅱ','朱赤麻痹牙1','',0);
insert into t_weapon values (null,'优雅弯刀1',4,429,0,'','ice:210','','','风漂龙的太刀。经过精雕细琢的冷艳刀锋，呈现出优美的流线型。','danger:90,warning:70,yellow:30,success:60,dark:150|danger:90,warning:70,yellow:30,success:110,dark:100','浮空龙的上鳞','',243,'风漂龙衍生','優雅彎刀Ⅰ','脉冲弯刀2','优雅弯刀2',0);

insert into t_weapon values (null,'优雅弯刀2',5,462,0,'','ice:240','','','风漂龙的太刀。经过精雕细琢的冷艳刀锋，呈现出优美的流线型。','danger:90,warning:100,yellow:40,success:40,blue:30,dark:100|danger:90,warning:100,yellow:40,success:40,blue:80,dark:50','风漂龙的上鳞','',243,'风漂龙衍生','優雅彎刀Ⅱ','优雅弯刀1','流星刀',0);

insert into t_weapon values (null,'流星刀',6,495,0,'','ice:300','','','风漂龙的太刀。将其砍倒吧。在仇敌映照在刀刃上之后，将其斩落于冰冷的地面上吧。','danger:80,warning:100,yellow:40,success:40,blue:40,dark:100|danger:80,warning:100,yellow:40,success:40,blue:90,dark:50','钢的上龙鳞','',243,'风漂龙衍生','流星刀','优雅弯刀2','幻光刀',3);

insert into t_weapon values (null,'幻光刀',8,528,0,'','ice:360','','','风漂龙的太刀。将其砍倒吧。在仇敌映照在刀刃上之后，将其斩落于冰冷的地面上吧。','danger:240,warning:20,yellow:20,success:20,blue:30,white:20,dark:50|danger:240,warning:20,yellow:20,success:20,blue:30,white:70,dark:0','风漂龙的厚皮','',243,'风漂龙衍生','幻光刀','流星刀','冰凌幻光·改',1);

insert into t_weapon values (null,'冰凌幻光·改',10,693,0,'','ice:420','','','风漂龙的太刀。将其砍倒吧。在仇敌映照在刀刃上之后，将其斩落于冰冷的地面上吧。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','霜翼风漂龙','',243,'风漂龙衍生','冰凌幻光‧改','幻光刀','霜漂幻光',0);

insert into t_weapon values (null,'霜漂幻光',10,726,0,'','ice:510','','','霜翼风漂龙的太刀。入魂一劈，让银刃映照的一切化为极致冰冻。','danger:90,warning:30,yellow:30,success:110,blue:40,white:50,dark:50|danger:90,warning:30,yellow:30,success:110,blue:40,white:100,dark:0','冰呪龙','',243,'风漂龙衍生','霜漂幻光','冰凌幻光·改','仙子冰川',0);

insert into t_weapon values (null,'仙子冰川',11,792,0,'','ice:540','','','霜翼风漂龙的太刀。入魂一劈，让银刃映照的一切化为极致冰冻。','danger:60,warning:20,yellow:30,success:90,blue:90,white:60,dark:50|danger:60,warning:20,yellow:30,success:90,blue:90,white:70,purple:40,dark:0','冰呪龙','',243,'风漂龙衍生','仙子冰川','霜漂幻光','',0);
insert into t_weapon values (null,'黑色弯刀1',3,396,0,'','','','','巨甲虫的太刀。由于附加了虫的素材，在重量维持不变的情况下，强度有所提升。','danger:80,warning:70,yellow:30,success:70,dark:150|danger:80,warning:70,yellow:30,success:120,dark:100','惨爪龙的鳞','',243,'巨甲虫衍生','黑色彎刀Ⅰ','脉冲弯刀1','黑色弯刀2',0);

insert into t_weapon values (null,'黑色弯刀2',4,429,0,'','','','','巨甲虫的太刀。由于附加了虫的素材，在重量维持不变的情况下，强度有所提升。','danger:70,warning:70,yellow:30,success:80,dark:150|danger:70,warning:70,yellow:30,success:130,dark:100','巨甲虫的坚壳','',243,'巨甲虫衍生','黑色彎刀Ⅱ','黑色弯刀1','黑色偃月刀1',0);

insert into t_weapon values (null,'黑色偃月刀1',5,462,0,'','paralysis:(180)','','68','巨甲虫的太刀。精挑细选出的巨型昆虫素材带来了残暴至极的武器性能。','danger:100,warning:100,yellow:40,success:40,blue:20,dark:100|danger:100,warning:100,yellow:40,success:40,blue:70,dark:50','苍火龙之翼','',243,'巨甲虫衍生','黑色偃月刀Ⅰ','黑色弯刀2','黑色偃月刀2',0);

insert into t_weapon values (null,'黑色偃月刀2',6,495,0,'','paralysis:(210)','','68','巨甲虫的太刀。精挑细选出的巨型昆虫素材带来了残暴至极的武器性能。','danger:80,warning:100,yellow:40,success:40,blue:40,dark:100|danger:80,warning:100,yellow:40,success:40,blue:90,dark:50','死尸的龙鳞','',243,'巨甲虫衍生','黑色偃月刀Ⅱ','黑色偃月刀1','黑色偃月刀3',3);

insert into t_weapon values (null,'黑色偃月刀3',6,528,0,'','paralysis:(240)','','68','巨甲虫的太刀。精挑细选出的巨型昆虫素材带来了残暴至极的武器性能。','danger:110,warning:30,yellow:60,success:80,blue:40,white:30,dark:50|danger:110,warning:30,yellow:60,success:80,blue:40,white:80,dark:0','怪物特浓体液','',243,'巨甲虫衍生','黑色偃月刀Ⅲ','黑色偃月刀2','深黑崩坏者1',3);

insert into t_weapon values (null,'深黑崩坏者1',9,660,0,'','paralysis:(270)','','68','巨甲虫的太刀。采用严选的巨大昆虫素材打造，让刀身兼具锐利度与韧性。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','碎龙','',243,'巨甲虫衍生','深黑崩壞者Ⅰ','黑色偃月刀3','深黑崩坏者2|碎龙偃月刀1',0);

insert into t_weapon values (null,'深黑崩坏者2',10,759,0,'','paralysis:(300)','','68','巨甲虫的太刀。采用严选的巨大昆虫素材打造，让刀身兼具锐利度与韧性。','danger:120,warning:20,yellow:20,success:70,blue:40,white:30,purple:50,dark:50|danger:120,warning:20,yellow:20,success:70,blue:40,white:30,purple:100,dark:0','惨爪龙的强硬筋','',243,'巨甲虫衍生','深黑崩壞者Ⅱ','深黑崩坏者1','',0);
insert into t_weapon values (null,'碎龙偃月刀1',10,726,0,'','blast:330','','','碎龙的太刀。刀身全面附着有爆炸性的黏菌，将受到攻击的猎物彻底粉碎。','danger:100,warning:30,yellow:30,success:110,blue:40,white:40,dark:50|danger:100,warning:30,yellow:30,success:110,blue:40,white:90,dark:0','苍火龙的重壳','',243,'碎龙衍生','碎龍偃月刀Ⅰ','深黑崩坏者1','碎龙偃月刀2',0);

insert into t_weapon values (null,'碎龙偃月刀2',10,792,0,'','blast:480','','67','碎龙的太刀。刀身全面附着有爆炸性的黏菌，将受到攻击的猎物彻底粉碎。','danger:90,warning:30,yellow:30,success:110,blue:40,white:50,dark:50|danger:90,warning:30,yellow:30,success:110,blue:40,white:100,dark:0','苍火龙的重壳','',243,'碎龙衍生','碎龍偃月刀Ⅱ','碎龙偃月刀1','',0);
insert into t_weapon values (null,'龙骨刀1',3,330,0,'','dragon:270','龙封力[小]','','带有龙属性的龙骨制太刀。以禁忌的技术打造而成。突破禁忌领域之作。','danger:110,warning:70,yellow:30,success:40,dark:150|danger:110,warning:70,yellow:30,success:90,dark:100','扭曲狂骨','',243,'龙骨衍生','龍骨刀Ⅰ','','龙骨刀2|熔山龙太刀1',0);

insert into t_weapon values (null,'龙骨刀2',4,363,0,'','dragon:330','龙封力[小]','','带有龙属性的龙骨制太刀。以禁忌的技术打造而成。突破禁忌领域之作。','danger:100,warning:70,yellow:30,success:50,dark:150|danger:100,warning:70,yellow:30,success:100,dark:100','古龙骨','',243,'龙骨衍生','龍骨刀Ⅱ','龙骨刀1','龙骨刀3',0);

insert into t_weapon values (null,'龙骨刀3',6,528,0,'','dragon:420','龙封力[小]','67','带有龙属性的龙骨制太刀。以禁忌的技术打造而成。突破禁忌领域之作。','danger:150,warning:100,yellow:30,success:30,blue:40,dark:50|danger:150,warning:100,yellow:30,success:30,blue:60,white:30,dark:0','刚龙骨','',243,'龙骨衍生','龍骨刀Ⅲ','龙骨刀2','封龙古刀1',3);

insert into t_weapon values (null,'封龙古刀1',10,693,0,'','dragon:510','龙封力[中]','67,67','带有龙属性的龙骨制太刀。以禁忌的技术打造而成。突破禁忌领域之作。','danger:130,warning:100,yellow:30,success:30,blue:60,dark:50|danger:130,warning:100,yellow:30,success:30,blue:80,white:30,dark:0','天地煌啼龙','',243,'龙骨衍生','封龍古刀Ⅰ','龙骨刀3','封龙古刀2|行云流水－和光－',0);

insert into t_weapon values (null,'封龙古刀2',11,792,0,'','dragon:630','龙封力[中]','67,67','带有龙属性的龙骨制太刀。以禁忌的技术打造而成。突破禁忌领域之作。','danger:70,warning:60,yellow:60,success:100,blue:60,dark:50|danger:70,warning:60,yellow:60,success:100,blue:80,white:30,dark:0','太古龙骨','',243,'龙骨衍生','封龍古刀Ⅱ','封龙古刀1','',0);
insert into t_weapon values (null,'行云流水－和光－',12,924,30,'','dragon:(450)','龙封力[大]','67,67','天地煌啼龙的太刀。不屈不挠的澄澈刀刃。所有苦厄都随挥斩一扫而空。','danger:170,warning:30,yellow:30,success:60,blue:50,white:10,dark:50|danger:170,warning:30,yellow:30,success:60,blue:50,white:30,purple:30,dark:0','天地煌啼龙','',243,'天地煌啼龙衍生','行雲流水－和光－','封龙古刀1','',0);
insert into t_weapon values (null,'熔山龙太刀1',5,528,20,'-20%','blast:300','','68','熔山龙的太刀。其剑锋犹如泰山之巅。天神般的热量让它的刀刃，挥斩散发出不可一世的威压。','danger:110,warning:50,yellow:80,success:60,dark:100|danger:110,warning:50,yellow:80,success:100,blue:10,dark:50','收束之地','',243,'熔山龙衍生','熔山龍太刀Ⅰ','龙骨刀1','熔山龙太刀2',0);

insert into t_weapon values (null,'熔山龙太刀2',7,726,20,'-20%','blast:360','','68','熔山龙的太刀。其剑锋犹如泰山之巅。天神般的热量让它的刀刃，挥斩散发出不可一世的威压。','danger:210,warning:30,yellow:40,success:70,dark:50|danger:210,warning:30,yellow:40,success:90,blue:30,dark:0','溟波龙','',243,'熔山龙衍生','熔山龍太刀Ⅱ','熔山龙太刀1','岩浆荣誉熔山刀|水螅·柱头',2);

insert into t_weapon values (null,'岩浆荣誉熔山刀',11,924,45,'-20%','blast:480','','68','熔山龙的太刀。封印着灼热汹涌的血潮。侵吞万物，将一切化为灰烬。','danger:140,warning:40,yellow:40,success:70,blue:60,dark:50|danger:140,warning:40,yellow:40,success:70,blue:70,white:20,purple:20,dark:0','龙脉的古龙骨','',243,'熔山龙衍生','岩漿榮譽熔山刀','熔山龙太刀2','',0);
insert into t_weapon values (null,'水螅·柱头',11,858,0,'+15%','water:210','','','溟波龙的太刀。表里互为黑暗与光明，明灭的刃光宛如凶兆自黑暗袭来。','danger:90,warning:80,yellow:30,success:30,blue:80,white:40,dark:50|danger:90,warning:80,yellow:30,success:30,blue:80,white:90,dark:0','天地煌啼龙','',243,'溟波龙衍生','水螅‧柱頭','熔山龙太刀2','暴君·柱头',0);

insert into t_weapon values (null,'暴君·柱头',12,924,0,'+15%','water:270','','','溟波龙的太刀。表里互为黑暗与光明，明灭的刃光宛如凶兆自黑暗袭来。','danger:70,warning:80,yellow:30,success:30,blue:80,white:60,dark:50|danger:70,warning:80,yellow:30,success:30,blue:80,white:110,dark:0','天地煌啼龙','',243,'溟波龙衍生','暴君‧柱頭','水螅·柱头','',0);
insert into t_weapon values (null,'黑钢太刀1',5,330,0,'','dragon:120','龙封力[小]','','带有龙属性的铁制太刀。以不明原理的技术制作而成。踏入了禁忌领域的野心之作。','danger:150,warning:110,yellow:40,dark:100|danger:150,warning:110,yellow:40,success:40,blue:10,dark:50','龙脉结晶','',243,'黑钢衍生','黑鋼太刀Ⅰ','','黑钢太刀2',0);

insert into t_weapon values (null,'黑钢太刀2',6,363,0,'','dragon:150','龙封力[小]','','带有龙属性的铁制太刀。以不明原理的技术制作而成。踏入了禁忌领域的野心之作。','danger:140,warning:110,yellow:40,success:10,dark:100|danger:140,warning:110,yellow:40,success:40,blue:20,dark:50','收束之地','',243,'黑钢衍生','黑鋼太刀Ⅱ','黑钢太刀1','帝王刀|冥灯龙太刀',3);
insert into t_weapon values (null,'帝王刀',7,561,0,'','blast:300','','','炎王龙的太刀。被摇曳火炎的色彩迷住的话，下一瞬间就会被烈焰斩击。','danger:100,warning:60,yellow:80,success:80,blue:30,dark:50|danger:100,warning:60,yellow:80,success:80,blue:60,white:20,dark:0','收束之地','',243,'黑钢衍生','帝王刀','黑钢太刀2','帝王刀【阳炎】',2);

insert into t_weapon values (null,'帝王刀【阳炎】',8,627,0,'','blast:300','','','炎王龙的太刀。被摇曳火炎的色彩迷住的话，下一瞬间就会被烈焰斩击。','danger:70,warning:50,yellow:60,success:120,blue:50,dark:50|danger:70,warning:50,yellow:60,success:120,blue:60,white:40,dark:0','炎王龙的重壳','',243,'黑钢衍生','帝王刀【陽炎】','帝王刀','炎帝王刀【海市蜃楼】',1);

insert into t_weapon values (null,'炎帝王刀【海市蜃楼】',11,858,0,'+10%','blast:360','','','炎王龙的太刀。被摇曳火炎的色彩迷住的话，下一瞬间就会被烈焰斩击。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','炎王龙的重壳','',243,'黑钢衍生','炎帝王刀【海市蜃樓】','帝王刀【阳炎】','',0);

insert into t_weapon values (null,'冥灯龙太刀',8,594,0,'+15%','dragon:180','龙封力[小]','67,67','冥灯龙的太刀。在万物之中也极其罕见的稀世灵宝。其无情的裁决将会斩断一切。','danger:130,warning:30,yellow:60,success:80,blue:40,white:10,dark:50|danger:130,warning:30,yellow:60,success:80,blue:40,white:60,dark:0','冥赤龙','',243,'冥灯龙衍生','冥燈龍太刀','黑钢太刀2','冥灯龙太刀改',1);

insert into t_weapon values (null,'冥灯龙太刀改',12,924,0,'+15%','dragon:270','龙封力[小]','73,73','冥灯龙的太刀。在万物之中也极其罕见的稀世灵宝。其无情的裁决将会斩断一切。','danger:100,warning:80,yellow:30,success:30,blue:80,white:30,dark:50|danger:100,warning:80,yellow:30,success:30,blue:80,white:80,dark:0','冥赤龙','',243,'冥灯龙衍生','冥燈龍太刀改','冥灯龙太刀','',0);

insert into t_weapon values (null,'天下无双刀',6,561,20,'','dragon:(120)','龙封力[大]','67','据说普天之下没有任何一把刀可与之比拟。毫无疑问的名刀。','danger:100,warning:50,yellow:50,success:80,blue:20,dark:100|danger:100,warning:50,yellow:50,success:80,blue:70,dark:50','火龙硬币','',243,'工房武器衍生','天下無雙刀','','天上天下无双刀',3);

insert into t_weapon values (null,'天上天下无双刀',8,693,20,'','dragon:(150)','龙封力[大]','67','据闻上天下地皆不存在能与其匹敌者的名刀。','danger:100,warning:60,yellow:60,success:100,blue:30,dark:50|danger:100,warning:60,yellow:60,success:100,blue:50,white:30,dark:0','英雄王硬币','',243,'工房武器衍生','天上天下無雙刀','天下无双刀','天上天下天地无双刀',1);

insert into t_weapon values (null,'天上天下天地无双刀',11,924,40,'','dragon:(180)','龙封力[大]','73','追求最强之名而生的豪杰之刀。强者皆败，彼亦神隐。','danger:60,warning:30,yellow:30,success:110,blue:40,white:80,dark:50|danger:60,warning:30,yellow:30,success:110,blue:40,white:130,dark:0','英雄王硬币','',243,'工房武器衍生','天上天下天地無雙刀','天上天下无双刀','',0);
insert into t_weapon values (null,'残酷痛苦太刀',6,693,0,'-25%','dragon:150','龙封力[大]','','恐暴龙的太刀。拔刀之时展露的刀锋将残酷地击溃猎物。','danger:60,warning:120,yellow:80,success:60,blue:30,dark:50|danger:60,warning:120,yellow:80,success:60,blue:30,white:50,dark:0','恐暴龙的黑皮','',243,'恐暴龙衍生','殘酷痛苦太刀','','悲惨痛苦太刀',3);

insert into t_weapon values (null,'悲惨痛苦太刀',7,759,0,'-25%','dragon:210','龙封力[大]','','恐暴龙的太刀。拔刀之时展露的刀锋将残酷地击溃猎物。','danger:50,warning:120,yellow:80,success:60,blue:40,dark:50|danger:50,warning:120,yellow:80,success:60,blue:40,white:50,dark:0','惶怒恐暴龙','',243,'恐暴龙衍生','悲慘痛苦太刀','残酷痛苦太刀','业刀破灭',2);

insert into t_weapon values (null,'业刀破灭',12,924,0,'-30%','dragon:330','龙封力[大]','','惶怒恐暴龙的太刀。连持刀之手都吞噬的疯狂刀刃，主动寻求鲜血而找寻猎物。','danger:160,warning:30,yellow:30,success:60,blue:50,white:20,dark:50|danger:160,warning:30,yellow:30,success:60,blue:50,white:40,purple:30,dark:0','惶怒恐暴龙','',243,'恐暴龙衍生','業刀破滅','悲惨痛苦太刀','',0);
insert into t_weapon values (null,'苍星太刀',3,363,0,'+20%','water:120','','','令人联想到苍星光芒的太刀。据说给人们越多的梦想或希望，它就会绽放越强的光芒。','danger:100,warning:70,yellow:30,success:50,dark:150|danger:100,warning:70,yellow:30,success:100,dark:100','苍星碎片','',243,'苍星衍生','蒼星的太刀','','苍星的太刀【舞龙】',0);

insert into t_weapon values (null,'苍星的太刀【舞龙】',7,495,0,'+30%','water:180','','67','令人联想到苍星光芒的太刀。据说给人们越多的梦想或希望，它就会绽放越强的光芒。','danger:120,warning:30,yellow:60,success:80,blue:40,white:20,dark:50|danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0','苍世的大宝玉','',243,'苍星衍生','蒼星的太刀【舞龍】','苍星太刀','真·苍星的太刀【舞龙】',2);

insert into t_weapon values (null,'真·苍星的太刀【舞龙】',12,891,0,'+30%','water:240','','73,73','让人联想到苍蓝星光芒的太刀，宛如奇迹般的美丽光辉，是带给众人梦想与希望的伟业之证。','danger:10,warning:40,yellow:50,success:50,blue:60,white:120,purple:20,dark:50|danger:10,warning:40,yellow:50,success:50,blue:60,white:120,purple:70,dark:0','苍世的大宝玉','',243,'苍星衍生','真‧蒼星的太刀【舞龍】','苍星的太刀【舞龙】','',0);
insert into t_weapon values (null,'皇后剑',7,594,0,'','blast:150','','68,67','炎妃龙的太刀。从封印有灵魂的苍蓝刀身上，可以感觉到一股隐藏的力量。','danger:110,warning:30,yellow:60,success:80,blue:40,white:30,dark:50|danger:110,warning:30,yellow:60,success:80,blue:40,white:80,dark:0','炎妃龙的上鳞','',243,'炎妃龙衍生','皇后劍','','皇后剑·炎妃|皇后剑·灭尽|皇后剑·冥灯',2);

insert into t_weapon values (null,'皇后剑·炎妃',8,594,0,'+20%','blast:180','','68,67','炎妃龙的太刀。以地狱的业火锻炼，蕴藏着保护使用者不受致命伤的奇迹。','danger:110,warning:30,yellow:60,success:80,blue:40,white:30,dark:50|danger:110,warning:30,yellow:60,success:80,blue:40,white:80,dark:0','炎妃龙的重壳','毅力',243,'炎妃龙衍生','皇后劍‧炎妃','皇后剑','魂焰龙刀·炎妃',1);

insert into t_weapon values (null,'魂焰龙刀·炎妃',12,825,0,'+20%','blast:270','','68,67','炎妃龙的太刀。以地狱的业火锻炼，蕴藏着保护使用者不受致命伤的奇迹。','danger:120,warning:30,yellow:90,success:30,blue:30,white:50,dark:50|danger:120,warning:30,yellow:90,success:30,blue:30,white:80,purple:20,dark:0','炎妃龙的重壳','毅力',243,'炎妃龙衍生','魂焰龍刀‧炎妃','皇后剑·炎妃','',0);
insert into t_weapon values (null,'皇后剑·灭尽',8,627,0,'','blast:150','','68,68','炎妃龙的太刀。与灭尽龙的素材产生共鸣，对使用者引发再生的奇迹。','danger:110,warning:30,yellow:60,success:80,blue:40,white:30,dark:50|danger:110,warning:30,yellow:60,success:80,blue:40,white:80,dark:0','灭尽龙的重壳','加速再生',243,'炎妃龙·灭尽衍生','皇后劍‧滅盡','皇后剑','魂焰龙刀·灭尽',1);
insert into t_weapon values (null,'魂焰龙刀·灭尽',12,891,0,'','blast:210','','68,68','炎妃龙的太刀。与灭尽龙的素材产生共鸣，对使用者引发再生的奇迹。','danger:120,warning:30,yellow:90,success:30,blue:30,white:50,dark:50|danger:120,warning:30,yellow:90,success:30,blue:30,white:80,purple:20,dark:0','灭尽龙的重壳','加速再生',243,'炎妃龙·灭尽衍生','魂焰龍刀‧滅盡','皇后剑·灭尽','',0);
insert into t_weapon values (null,'皇后剑·冥灯',8,594,0,'+10%','blast:240','','67,67','炎妃龙的太刀。与冥灯龙的素材产生共鸣，其中蕴藏着抵御威慑的力量。','danger:110,warning:30,yellow:60,success:80,blue:40,white:30,dark:50|danger:110,warning:30,yellow:60,success:80,blue:40,white:80,dark:0','灵脉的古龙骨','利刃／弹丸节约',243,'炎妃龙·冥灯衍生','皇后劍‧冥燈','皇后剑','魂焰龙刀·冥灯',1);

insert into t_weapon values (null,'魂焰龙刀·冥灯',12,825,0,'+10%','blast:330','','67,67','炎妃龙的太刀。与冥灯龙的素材产生共鸣，其中蕴藏着抵御威慑的力量。','danger:120,warning:30,yellow:90,success:30,blue:30,white:50,dark:50|danger:120,warning:30,yellow:90,success:30,blue:30,white:80,purple:20,dark:0','灵脉的古龙骨','利刃／弹丸节约',243,'炎妃龙·冥灯衍生','魂焰龍刀‧冥燈','皇后剑·冥灯','',0);
insert into t_weapon values (null,'鬼薙刀',11,957,0,'-15%','thunder:90','','73','金狮子的太刀。依据拥有东方之力的僧人口述秘传所打造而成的太刀。','danger:110,warning:100,yellow:40,success:50,blue:50,dark:50|danger:110,warning:100,yellow:40,success:50,blue:50,white:50,dark:0','金狮子','',243,'金狮子衍生','鬼薙刀','','大鬼薙刀',0);

insert into t_weapon values (null,'大鬼薙刀',12,1023,0,'-15%','thunder:120','','73','金狮子的太刀。依据拥有东方之力的僧人口述秘传所打造而成的太刀。','danger:100,warning:100,yellow:40,success:50,blue:60,dark:50|danger:100,warning:100,yellow:40,success:50,blue:60,white:50,dark:0','历战的煌毛','',243,'金狮子衍生','大鬼薙刀','鬼薙刀','',0);
insert into t_weapon values (null,'鬼神薙刀【阿修罗】',12,957,0,'+15%','thunder:270','','','激昂金狮子的太刀。金狮子之斗魂化为黄金雷火，炙热燃烧。','danger:120,warning:20,yellow:20,success:70,blue:40,white:30,purple:50,dark:50|danger:120,warning:20,yellow:20,success:70,blue:40,white:30,purple:100,dark:0','激昂金狮子','',243,'激昂金狮子衍生改','鬼神薙刀【阿修羅】','','',0);
insert into t_weapon values (null,'狱刀龙骨',11,825,0,'','dragon:240','龙封力[中]','68','狱狼龙的太刀。豪迈斩开宇宙万物，苍天也臣服的累世业力。','danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:20,dark:50|danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:70,dark:0','狱狼龙','',243,'狱狼龙衍生','獄刀龍骨','','狼牙刀【恶狱】',0);

insert into t_weapon values (null,'狼牙刀【恶狱】',12,891,0,'','dragon:300','龙封力[中]','68','狱狼龙的太刀。豪迈斩开宇宙万物，苍天也臣服的累世业力。','danger:130,warning:20,yellow:20,success:70,blue:40,white:30,purple:40,dark:50|danger:130,warning:20,yellow:20,success:70,blue:40,white:30,purple:90,dark:0','历战的灭龙壳','',243,'狱狼龙衍生','狼牙刀【惡獄】','狱刀龙骨','',0);
insert into t_weapon values (null,'碎光之晓刀',12,990,0,'','blast:270','','73,67','猛爆碎龙的太刀。抽出刀鞘的瞬间，周边一带将化为灼热汹涌的焦土。','danger:150,warning:30,yellow:90,success:30,blue:30,white:50,purple:20,dark:0|danger:150,warning:30,yellow:90,success:30,blue:30,white:50,purple:20,dark:0','猛爆碎龙','',243,'猛爆碎龙衍生改','碎光之曉刀','','',0);
insert into t_weapon values (null,'漆黑爪',11,825,0,'','dragon:510','龙封力[小]','68','煌黑龙的太刀。持有者将受黑暗魅惑，献身于吞噬光明的怪物。','danger:120,warning:20,yellow:20,success:70,blue:40,white:30,purple:50,dark:50|danger:120,warning:20,yellow:20,success:70,blue:40,white:30,purple:100,dark:0','煌黑龙','',243,'煌黑龙衍生','漆黑爪','','漆黑爪【终焉】',0);

insert into t_weapon values (null,'漆黑爪【终焉】',12,924,0,'','dragon:660','龙封力[小]','68,68','煌黑龙的太刀。持有者将受黑暗魅惑，献身于吞噬光明的怪物。','danger:80,warning:20,yellow:20,success:70,blue:40,white:30,purple:90,dark:50|danger:80,warning:20,yellow:20,success:70,blue:40,white:30,purple:140,dark:0','煌黑龙','',243,'煌黑龙衍生','漆黑爪【終焉】','漆黑爪','',0);
insert into t_weapon values (null,'钢铁十字鎬【采掘狂】',10,825,30,'+20%','blast:(510)','','','融入矿工非凡热情的十字鎬。据说拿在手上会让人心无旁鶩地专心挖煤。分类为太刀。','danger:110,warning:30,yellow:30,success:110,blue:40,white:30,dark:50|danger:110,warning:30,yellow:30,success:110,blue:40,white:80,dark:0','十字鎬票','',243,'工房武器衍生2','鋼鐵十字鎬【採掘狂】','','超钢铁十字鎬【采掘鬼】',0);

insert into t_weapon values (null,'超钢铁十字鎬【采掘鬼】',11,858,30,'+30%','blast:(540)','','','融入矿工非凡热情的十字鎬。据说拿在手上会让人心无旁鶩地专心挖煤。分类为太刀。','danger:90,warning:30,yellow:30,success:110,blue:40,white:50,dark:50|danger:90,warning:30,yellow:30,success:110,blue:40,white:100,dark:0','荒地的结晶','',243,'工房武器衍生2','超鋼鐵十字鎬【採掘鬼】','钢铁十字鎬【采掘狂】','',0);

insert into t_weapon values (null,'公会宫殿配刀',10,825,30,'+10%','water:(420)','','67','立下特别功勳的公会骑士才有资格获得的轻弩。庄严耀眼的姿态显现出身为猎人的尊严。','danger:150,warning:30,yellow:30,success:60,blue:50,white:30,dark:50|danger:150,warning:30,yellow:30,success:60,blue:50,white:50,purple:30,dark:0','祭典票','',243,'公会宫殿衍生','公會宮殿配刀','','宫廷礼刀【将星】',0);

insert into t_weapon values (null,'宫廷礼刀【将星】',12,891,30,'+15%','water:(510)','','67','立下特别功勳的公会骑士才有资格获得的轻弩。庄严耀眼的姿态显现出身为猎人的尊严。','danger:150,warning:30,yellow:30,success:60,blue:50,white:30,dark:50|danger:150,warning:30,yellow:30,success:60,blue:50,white:30,purple:50,dark:0','英雄王硬币','',243,'公会宫殿衍生','宮廷禮刀【將星】','公会宫殿配刀','',0);
insert into t_weapon values (null,'黑龙刀',11,1023,0,'-40%','dragon:90','龙封力[大]','73,73','黑龙的太刀。只要被其砍伤后伤口就无法痊愈，即使百年后仍将受伤痛的折磨。','danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:20,dark:50|danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:70,dark:0','黑龙','',243,'黑龙衍生','黑龍刀','','黑龙歼灭刀',0);

insert into t_weapon values (null,'黑龙歼灭刀',12,1155,0,'-30%','dragon:150','龙封力[大]','73,73','黑龙的太刀。只要被其砍伤后伤口就无法痊愈，即使百年后仍将受伤痛的折磨。','danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:20,dark:50|danger:150,warning:20,yellow:20,success:70,blue:40,white:30,purple:70,dark:0','黑龙','',243,'黑龙衍生','黑龍殲滅刀','黑龙刀','',0);

insert into t_weapon values (null,'赤龙闪光刃·火',12,891,0,'+5%','fire:180','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧火','','',0);
insert into t_weapon values (null,'赤龙闪光刃·水',12,891,0,'+5%','water:180','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧水','','',0);
insert into t_weapon values (null,'赤龙闪光刃·冰',12,891,0,'+5%','ice:180','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧冰','','',0);
insert into t_weapon values (null,'赤龙闪光刃·雷',12,891,0,'+5%','thunder:180','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧雷','','',0);
insert into t_weapon values (null,'赤龙闪光刃·龙',12,891,0,'+5%','dragon:180','龙封力[中]','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧龍','','',0);
insert into t_weapon values (null,'赤龙闪光刃·毒',12,891,0,'+5%','poison:210','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧毒','','',0);
insert into t_weapon values (null,'赤龙闪光刃·麻痹',12,891,0,'+5%','paralysis:120','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧麻痺','','',0);
insert into t_weapon values (null,'赤龙闪光刃·睡眠',12,891,0,'+5%','sleep:120','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧睡眠','','',0);
insert into t_weapon values (null,'赤龙闪光刃·爆破',12,891,0,'+5%','blast:210','','73','冥赤龙的太刀。借由与特殊素材产生反应，让潜藏的龙脉之力觉醒。','danger:100,warning:50,yellow:50,success:50,blue:60,white:40,dark:50|danger:100,warning:50,yellow:50,success:50,blue:60,white:90,dark:0','','',243,'','赤龍閃光刃‧爆破','','',0);
insert into t_weapon values (null,'金色的太刀·水',6,528,40,'','water:(210)','','','用绚辉龙的金属片加工制成的太刀。具有的特性不明，无法完全激发出它的性能。','danger:60,warning:60,yellow:20,success:150,blue:90,white:20,dark:0|danger:60,warning:60,yellow:20,success:150,blue:90,white:20,dark:0','','',243,'','金色的太刀‧水','','',3);
insert into t_weapon values (null,'金色的太刀·毒',6,528,40,'+10%','poison:(210)','','','用绚辉龙的金属片加工制成的太刀。具有的特性不明，无法完全激发出它的性能。','danger:90,warning:60,yellow:60,success:100,blue:60,white:30,dark:0|danger:90,warning:60,yellow:60,success:100,blue:60,white:30,dark:0','','',243,'','金色的太刀‧毒','','',3);
insert into t_weapon values (null,'金色的太刀·麻痹',6,495,40,'','paralysis:(150)','','','用绚辉龙的金属片加工制成的太刀。具有的特性不明，无法完全激发出它的性能。','danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0|danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0','','',243,'','金色的太刀‧麻痺','','',3);
insert into t_weapon values (null,'金色的太刀·搔',6,495,40,'+20%','sleep:120','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:90,warning:60,yellow:80,success:80,blue:70,white:20,dark:0|danger:90,warning:60,yellow:80,success:80,blue:70,white:20,dark:0','','',243,'','金色的太刀‧搔','','',3);
insert into t_weapon values (null,'金色的太刀·泥鱼',6,594,40,'','water:180','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:170,warning:100,yellow:30,success:30,blue:40,white:30,dark:0|danger:170,warning:100,yellow:30,success:30,blue:40,white:30,dark:0','','',243,'','金色的太刀‧泥魚','','',3);
insert into t_weapon values (null,'金色的太刀·飞雷',6,528,40,'+30%','thunder:120','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:140,warning:100,yellow:30,success:30,blue:70,white:30,dark:0|danger:140,warning:100,yellow:30,success:30,blue:70,white:30,dark:0','','',243,'','金色的太刀‧飛雷','','',3);
insert into t_weapon values (null,'金色的太刀·蛮颚',6,561,40,'-10%','fire:180','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:110,warning:120,yellow:40,success:50,blue:80,dark:0|danger:110,warning:120,yellow:40,success:50,blue:80,dark:0','','',243,'','金色的太刀‧蠻顎','','',3);
insert into t_weapon values (null,'金色的太刀·黑甲',6,396,40,'','paralysis:120','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0|danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0','','',243,'','金色的太刀‧黑甲','','',3);
insert into t_weapon values (null,'金色的太刀·眩',6,528,40,'','thunder:(180)','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:80,warning:50,yellow:60,success:120,blue:50,white:40,dark:0|danger:80,warning:50,yellow:60,success:120,blue:50,white:40,dark:0','','',243,'','金色的太刀‧眩','','',3);
insert into t_weapon values (null,'金色的太刀·风漂',6,462,40,'','ice:180','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0|danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0','','',243,'','金色的太刀‧風漂','','',3);
insert into t_weapon values (null,'金色的太刀·尸套',6,561,40,'+10%','dragon:120','龙封力[中]','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0|danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0','','',243,'','金色的太刀‧屍套','','',3);
insert into t_weapon values (null,'金色的太刀·爆锤',6,528,60,'','fire:90','','67','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:100,warning:50,yellow:50,success:80,blue:120,dark:0|danger:100,warning:50,yellow:50,success:80,blue:120,dark:0','','',243,'','金色的太刀‧爆鎚','','',3);
insert into t_weapon values (null,'金色的太刀·熔山',6,528,50,'-20%','blast:180','','','用绚辉龙的金属片加工制成的太刀。为了进行研究，也加入了其他怪物素材。','danger:130,warning:120,yellow:40,success:50,blue:60,dark:0|danger:130,warning:120,yellow:40,success:50,blue:60,dark:0','','',243,'','金色的太刀‧熔山','','',3);
insert into t_weapon values (null,'铠罗剑·搔',7,561,40,'+20%','sleep:210','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:90,warning:60,yellow:80,success:80,blue:70,white:20,dark:0|danger:90,warning:60,yellow:80,success:80,blue:70,white:20,dark:0','','',243,'','鎧羅劍‧搔','','',2);
insert into t_weapon values (null,'铠罗剑·泥鱼',7,660,40,'','water:360','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:170,warning:100,yellow:30,success:30,blue:40,white:30,dark:0|danger:170,warning:100,yellow:30,success:30,blue:40,white:30,dark:0','','',243,'','鎧羅劍‧泥魚','','',2);
insert into t_weapon values (null,'铠罗剑·飞雷',7,594,40,'+30%','thunder:270','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:140,warning:100,yellow:30,success:30,blue:70,white:30,dark:0|danger:140,warning:100,yellow:30,success:30,blue:70,white:30,dark:0','','',243,'','鎧羅劍‧飛雷','','',2);
insert into t_weapon values (null,'铠罗剑·蛮颚',7,693,40,'-10%','fire:390','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:110,warning:120,yellow:40,success:50,blue:80,dark:0|danger:110,warning:120,yellow:40,success:50,blue:80,dark:0','','',243,'','鎧羅劍‧蠻顎','','',2);
insert into t_weapon values (null,'铠罗剑·黑甲',7,528,40,'','paralysis:210','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0|danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0','','',243,'','鎧羅劍‧黑甲','','',2);
insert into t_weapon values (null,'铠罗剑·眩',7,627,40,'','thunder:(360)','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:80,warning:50,yellow:60,success:120,blue:50,white:40,dark:0|danger:80,warning:50,yellow:60,success:120,blue:50,white:40,dark:0','','',243,'','鎧羅劍‧眩','','',2);
insert into t_weapon values (null,'铠罗剑·风漂',7,528,40,'','ice:360','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0|danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0','','',243,'','鎧羅劍‧風漂','','',2);
insert into t_weapon values (null,'铠罗剑·尸套',7,660,40,'+10%','dragon:270','龙封力[中]','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0|danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0','','',243,'','鎧羅劍‧屍套','','',2);
insert into t_weapon values (null,'铠罗剑·爆锤',7,660,60,'','fire:120','','67','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:100,warning:50,yellow:50,success:80,blue:120,dark:0|danger:100,warning:50,yellow:50,success:80,blue:120,dark:0','','',243,'','鎧羅劍‧爆鎚','','',2);
insert into t_weapon values (null,'铠罗剑·熔山',7,726,50,'-20%','blast:360','','','用绚辉龙的金属片加工制成的太刀。保留素材的特性，成功加入了新的特质。','danger:130,warning:120,yellow:40,success:50,blue:60,dark:0|danger:130,warning:120,yellow:40,success:50,blue:60,dark:0','','',243,'','鎧羅劍‧熔山','','',2);
insert into t_weapon values (null,'铠罗剑·水',8,627,40,'','water:(420)','','67','用绚辉龙的金属片加工制成的太刀。保留住隐藏在素材里的力量，成功炼制而成。','danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0|danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0','','',243,'','鎧羅劍‧水','','',1);
insert into t_weapon values (null,'铠罗剑·毒',8,627,40,'+10%','poison:(420)','','67','用绚辉龙的金属片加工制成的太刀。保留住隐藏在素材里的力量，成功炼制而成。','danger:70,warning:50,yellow:60,success:120,blue:60,white:40,dark:0|danger:70,warning:50,yellow:60,success:120,blue:60,white:40,dark:0','','',243,'','鎧羅劍‧毒','','',1);
insert into t_weapon values (null,'铠罗剑·麻痹',8,561,40,'','paralysis:(330)','','67','用绚辉龙的金属片加工制成的太刀。保留住隐藏在素材里的力量，成功炼制而成。','danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0|danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0','','',243,'','鎧羅劍‧麻痺','','',1);
insert into t_weapon values (null,'铠罗剑·火',8,660,40,'','fire:(450)','','67','用绚辉龙的金属片加工制成的太刀。保留住隐藏在素材里的力量，成功炼制而成。','danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0|danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0','','',243,'','鎧羅劍‧火','','',1);
insert into t_weapon values (null,'皇金太刀·飞雷',8,627,20,'+20%','thunder:330','','67','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:140,warning:100,yellow:30,success:30,blue:70,white:30,dark:0|danger:140,warning:100,yellow:30,success:30,blue:70,white:30,dark:0','','会心攻击【属性】',243,'','帝王金太刀‧飛雷','','',1);
insert into t_weapon values (null,'皇金太刀·风漂',8,561,20,'+15%','ice:390','','67','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:220,warning:20,yellow:20,success:20,blue:30,white:90,dark:0|danger:220,warning:20,yellow:20,success:20,blue:30,white:90,dark:0','','会心攻击【属性】',243,'','帝王金太刀‧風漂','','',1);
insert into t_weapon values (null,'皇金太刀·尸套',8,676.5,20,'+15%','dragon:330','龙封力[中]','67','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0|danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0','','会心攻击【属性】',243,'','帝王金太刀‧屍套','','',1);
insert into t_weapon values (null,'皇金太刀·熔山',8,693,35,'+10%','blast:420','','67','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:110,warning:50,yellow:50,success:80,blue:110,dark:0|danger:110,warning:50,yellow:50,success:80,blue:110,dark:0','','会心攻击【特殊】',243,'','帝王金太刀‧熔山','','',1);
insert into t_weapon values (null,'皇金太刀·水',8,610.5,20,'+15%','water:390','','','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0|danger:200,warning:70,yellow:20,success:20,blue:50,white:40,dark:0','','会心攻击【属性】',243,'','帝王金太刀‧水','','',1);
insert into t_weapon values (null,'皇金太刀·火',8,627,20,'+20%','fire:390','','','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0|danger:230,warning:20,yellow:20,success:20,blue:30,white:80,dark:0','','会心攻击【属性】',243,'','帝王金太刀‧火','','',1);
insert into t_weapon values (null,'皇金太刀·麻痹',8,528,20,'+15%','paralysis:270','','','绚辉龙的特别金属片所制作的太刀。素材中潜藏的力量，被提升至极限。','danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0|danger:120,warning:30,yellow:60,success:80,blue:40,white:70,dark:0','','会心攻击【特殊】',243,'','帝王金太刀‧麻痺','','',1);
insert into t_weapon values (null,'骨镰',11,858,0,'','','','','将骸骨反复打磨制成的的太刀。充满野性的必杀连击，据说连巨大的岩石都能轻易一刀两断。','danger:120,warning:30,yellow:30,success:60,blue:50,white:60,dark:50|danger:120,warning:30,yellow:30,success:60,blue:50,white:80,purple:30,dark:0','','',243,'','骨鐮','','',0);
